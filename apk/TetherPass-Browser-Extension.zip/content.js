/**
 * CardVault Content Script
 * Detects payment, bank account, and credential input fields and renders
 * floating inline autofill suggestion chips when authorized by mobile app.
 */

(function () {
  var activeDropdown = null;
  var activeInput = null;
  var selectedItemIndex = -1;
  var managedInput = null;
  var originalAutocomplete = null;
  var isVaultUnlocked = false;

  function purgeAllTetherPassElements() {
    isVaultUnlocked = false;
    restoreBrowserAutofill();
    if (activeDropdown) {
      activeDropdown.remove();
      activeDropdown = null;
    }
    if (activeFloatingPill) {
      activeFloatingPill.remove();
      activeFloatingPill = null;
    }
    if (activePromptCard) {
      activePromptCard.remove();
      activePromptCard = null;
    }
    document.querySelectorAll('.cv-floating-pill, .cv-autofill-dropdown, .cv-save-prompt-card').forEach(el => el.remove());
  }

  function updateVaultStatus(status) {
    if (status && status.isAuthorized && status.isUnlocked) {
      const now = Date.now();
      if (!status.authExpiresAt || now < status.authExpiresAt) {
        isVaultUnlocked = true;
        return;
      }
    }
    purgeAllTetherPassElements();
  }

  function queryVaultStatus() {
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime?.sendMessage) {
        chrome.runtime.sendMessage({ action: 'GET_STATUS' }, (status) => {
          if (typeof chrome !== 'undefined' && chrome.runtime?.lastError) {
            purgeAllTetherPassElements();
            return;
          }
          updateVaultStatus(status);
        });
      } else {
        purgeAllTetherPassElements();
      }
    } catch (_) {
      purgeAllTetherPassElements();
    }
  }

  // Initial status check: by default, extension acts completely DEAD until confirmed unlocked
  queryVaultStatus();

  // Re-verify status on tab visibility or window focus
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) queryVaultStatus();
  });
  window.addEventListener('focus', queryVaultStatus);

  function suppressBrowserAutofill(input) {
    if (!isVaultUnlocked || !input) return;
    managedInput = input;
    if (input.getAttribute('autocomplete') !== 'off' && (!input.dataset || !input.dataset.tpOrigAc)) {
      originalAutocomplete = input.getAttribute('autocomplete');
      if (input.dataset) {
        input.dataset.tpOrigAc = originalAutocomplete !== null ? originalAutocomplete : '__none__';
      }
    }
    input.setAttribute('autocomplete', 'off');
  }

  function restoreBrowserAutofill() {
    if (managedInput) {
      const orig = managedInput.dataset?.tpOrigAc;
      if (orig && orig !== '__none__') {
        managedInput.setAttribute('autocomplete', orig);
      } else if (originalAutocomplete !== null) {
        managedInput.setAttribute('autocomplete', originalAutocomplete);
      } else {
        managedInput.removeAttribute('autocomplete');
      }
      managedInput = null;
      originalAutocomplete = null;
    }
  }

  function updateRowHighlight(rows) {
    if (!rows) return;
    rows.forEach((r, idx) => {
      if (idx === selectedItemIndex) {
        r.classList.add('cv-selected');
        r.scrollIntoView({ block: 'nearest' });
      } else {
        r.classList.remove('cv-selected');
      }
    });
  }


  function getElementTextContext(input) {
    if (!input) return '';
    const pieces = [];

    if (input.name) pieces.push(input.name);
    if (input.id) pieces.push(input.id);
    if (input.placeholder) pieces.push(input.placeholder);
    if (input.title) pieces.push(input.title);
    if (input.getAttribute('autocomplete')) pieces.push(input.getAttribute('autocomplete'));
    if (input.getAttribute('aria-label')) pieces.push(input.getAttribute('aria-label'));
    if (input.getAttribute('aria-placeholder')) pieces.push(input.getAttribute('aria-placeholder'));
    if (input.getAttribute('data-testid')) pieces.push(input.getAttribute('data-testid'));
    if (input.getAttribute('data-field')) pieces.push(input.getAttribute('data-field'));

    // Check aria-labelledby & aria-describedby
    const labelledBy = input.getAttribute('aria-labelledby');
    if (labelledBy) {
      labelledBy.split(/\s+/).forEach(id => {
        const el = document.getElementById(id);
        if (el && el.textContent) pieces.push(el.textContent.trim());
      });
    }
    const describedBy = input.getAttribute('aria-describedby');
    if (describedBy) {
      describedBy.split(/\s+/).forEach(id => {
        const el = document.getElementById(id);
        if (el && el.textContent) pieces.push(el.textContent.trim());
      });
    }

    // Check associated HTML <label> elements
    if (input.labels && input.labels.length > 0) {
      for (const lbl of input.labels) {
        if (lbl.textContent) pieces.push(lbl.textContent.trim());
      }
    }

    // Check closest label or container
    const parentLabel = input.closest('label');
    if (parentLabel && parentLabel.textContent) pieces.push(parentLabel.textContent.trim());

    // Check previous & next siblings
    let sib = input.previousElementSibling;
    let sibCount = 0;
    while (sib && sibCount < 3) {
      const txt = sib.textContent ? sib.textContent.trim() : '';
      if (txt && txt.length < 80) pieces.push(txt);
      sib = sib.previousElementSibling;
      sibCount++;
    }
    sib = input.nextElementSibling;
    sibCount = 0;
    while (sib && sibCount < 3) {
      const txt = sib.textContent ? sib.textContent.trim() : '';
      if (txt && txt.length < 80) pieces.push(txt);
      sib = sib.nextElementSibling;
      sibCount++;
    }

    // Inspect immediate field container for floating labels / headers
    let cur = input.parentElement;
    for (let depth = 0; depth < 2 && cur && cur !== document.body && cur.tagName !== 'FORM'; depth++) {
      if (cur.className && typeof cur.className === 'string') pieces.push(cur.className);
      if (cur.id) pieces.push(cur.id);

      // Only inspect descendant text elements if this container is dedicated to this input
      // (does not wrap multiple separate inputs like an entire form or table)
      const siblingInputs = cur.querySelectorAll('input:not([type="hidden"])');
      if (siblingInputs.length <= 1) {
        const textEls = cur.querySelectorAll('label, span, div, p, strong, b, small, h1, h2, h3, h4, h5, h6');
        textEls.forEach(el => {
          if (el !== input && !el.contains(input)) {
            const txt = el.textContent ? el.textContent.trim() : '';
            if (txt && txt.length > 0 && txt.length < 60) {
              pieces.push(txt);
            }
          }
        });
      }
      cur = cur.parentElement;
    }

    return pieces.join(' ').toLowerCase();
  }

  // Field type classifiers
  function classifyInput(input) {
    if (!input || input.type === 'hidden' || input.type === 'submit' || input.type === 'button') return null;

    const raw = getElementTextContext(input);
    const norm = raw.replace(/[-_./]/g, ' ');
    const type = (input.type || '').toLowerCase();
    const origAc = input.dataset?.tpOrigAc;
    const rawAc = input.getAttribute('autocomplete') || '';
    const autocomplete = ((origAc && origAc !== '__none__') ? origAc : rawAc).toLowerCase();
    const ph = (input.placeholder || '').toLowerCase();

    // 0. Explicit Password Input Type
    if (type === 'password') {
      if (input.maxLength >= 3 && input.maxLength <= 4 && (norm.includes('cvv') || norm.includes('cvc') || norm.includes('security code'))) {
        return 'CVV';
      }
      return 'PASSWORD';
    }

    // 1. 2FA / TOTP / One-Time Passcode
    const isTotpCandidate = (
      autocomplete.includes('one-time-code') ||
      raw.includes('totp') || raw.includes('2fa') || raw.includes('mfa') ||
      raw.includes('otp') || raw.includes('authenticator') ||
      raw.includes('verification_code') || raw.includes('verification-code') ||
      raw.includes('auth_code') || raw.includes('auth-code') ||
      norm.includes('verification code') || norm.includes('two factor') ||
      norm.includes('2 step') || norm.includes('two step') ||
      (type === 'text' && input.maxLength === 6 && (norm.includes('code') || norm.includes('pin'))) ||
      ((norm.includes('security code') || norm.includes('passcode') || norm.includes('auth code')) &&
       !norm.includes('card') && !norm.includes('cvv') && !norm.includes('payment') && !norm.includes('credit') && !norm.includes('debit'))
    );
    if (isTotpCandidate) {
      return 'TOTP';
    }

    // 2. CVV / Security Code (Card payment only)
    if (
      autocomplete.includes('cc-csc') || raw.includes('cvv') || raw.includes('cvc') || raw.includes('cid') || raw.includes('csc') ||
      ((norm.includes('security code') || norm.includes('verification code')) && (norm.includes('card') || norm.includes('payment') || input.maxLength === 3 || input.maxLength === 4))
    ) {
      return 'CVV';
    }

    // 3. Expiry Date (Full, Month, Year)
    const isExpiryRelated = !raw.includes('dob') && !raw.includes('birth') && !autocomplete.includes('bday') && (
      autocomplete.includes('cc-exp') || norm.includes('expiry') || norm.includes('expire') ||
      norm.includes('expiration') || norm.includes('exp date') || norm.includes('expiry date') ||
      norm.includes('valid thru') || norm.includes('valid till') || norm.includes('valid upto') ||
      raw.includes('mm/yy') || raw.includes('mm / yy') || raw.includes('mm-yy') || raw.includes('mmyy') ||
      raw.includes('ccexp') || raw.includes('card_exp') || ph === 'mm' || ph === 'yy' || ph === 'yyyy' ||
      ph === 'mm/yy' || ph === 'mm / yy'
    );

    if (isExpiryRelated) {
      const isMonth = autocomplete.includes('cc-exp-month') || raw.includes('month') || raw.includes('exp_m') ||
        raw.includes('ccexpm') || ph === 'mm' || (input.maxLength === 2 && (norm.includes('month') || ph.includes('m')));
      const isYear = autocomplete.includes('cc-exp-year') || raw.includes('year') || raw.includes('exp_y') ||
        raw.includes('ccexpy') || ph === 'yy' || ph === 'yyyy' || (input.maxLength <= 4 && (norm.includes('year') || ph.includes('y')));

      if (isMonth && !isYear) return 'EXPIRY_MONTH';
      if (isYear && !isMonth) return 'EXPIRY_YEAR';
      return 'EXPIRY';
    }

    // 4. Cardholder Name (Check BEFORE Card Number so "Name on Card" matches Cardholder Name!)
    if (
      autocomplete.includes('cc-name') || raw.includes('cardholder') || raw.includes('card_holder') ||
      norm.includes('name on card') || norm.includes('card holder') || norm.includes('cardholder') ||
      raw.includes('card_name') || raw.includes('cardname') ||
      ((norm.includes('name') || norm.includes('holder')) && norm.includes('card') && !norm.includes('nickname'))
    ) {
      return 'CARD_HOLDER';
    }

    // 5. Card Number
    if (
      autocomplete.includes('cc-number') || raw.includes('cardnumber') || raw.includes('card_number') ||
      raw.includes('card_no') || raw.includes('cardno') || norm.includes('card number') ||
      norm.includes('card no') || raw.includes('cc_num') || raw.includes('cc-num') || raw.includes('ccnum') ||
      ph.includes('xxxx') || ph.includes('••••') ||
      (norm.includes('card') && !norm.includes('holder') && !norm.includes('name') && !norm.includes('exp') && !norm.includes('cvv') && !norm.includes('nickname')) ||
      (type === 'tel' && (norm.includes('credit') || norm.includes('debit') || norm.includes('card')))
    ) {
      return 'CARD_NUMBER';
    }

    // 6. Bank IFSC Code
    if (raw.includes('ifsc') || norm.includes('ifsc code') || norm.includes('bank code')) {
      return 'IFSC';
    }

    // 7. Bank Account Number
    if (
      raw.includes('account_number') || raw.includes('accountnumber') || raw.includes('acc_num') ||
      raw.includes('acc_no') || norm.includes('account number') || norm.includes('account no') ||
      norm.includes('bank account')
    ) {
      return 'ACCOUNT_NUMBER';
    }

    // 8. User ID / Customer ID / Username / Email / Netbanking ID (Checked BEFORE generic text password!)
    // Strictly requires an actual login context: either explicit username/customer attribute,
    // OR a form/page containing a password field. General emails (newsletters, shipping, contact) are ignored!
    const hasPasswordInForm = !!(input.form?.querySelector('input[type="password"]') || document.querySelector('input[type="password"]'));
    const isExplicitLoginField = autocomplete === 'username' || autocomplete === 'current-password' ||
      raw.includes('customer id') || raw.includes('customer_id') || raw.includes('cust_id') || raw.includes('custid') ||
      raw.includes('customer no') || raw.includes('customerno') || raw.includes('client id') || raw.includes('clientid') ||
      raw.includes('user id') || raw.includes('userid') || raw.includes('user_id') ||
      raw.includes('username') || raw.includes('user_name') || raw.includes('login id') || raw.includes('loginid') ||
      raw.includes('cif') || raw.includes('cif no') || raw.includes('cif_no') ||
      norm.includes('customer id') || norm.includes('user id') || norm.includes('login id') || norm.includes('client id') ||
      norm.includes('customer no') || norm.includes('cust id') || norm.includes('cif no') ||
      raw.includes('netbanking') || raw.includes('sign in') || raw.includes('signin');

    if (isExplicitLoginField || (hasPasswordInForm && (type === 'email' || autocomplete.includes('email') || raw.includes('email') || raw.includes('login')))) {
      return 'USER_ID';
    }

    // 9. Text-based Password / MPIN (e.g. unmasked password toggled with eye icon, strictly requires password keywords in its own attributes)
    const selfName = (input.name || '').toLowerCase();
    const selfId = (input.id || '').toLowerCase();
    if (
      autocomplete.includes('current-password') || autocomplete.includes('new-password') ||
      selfName.includes('password') || selfName.includes('pass') || selfName.includes('pwd') || selfName.includes('mpin') ||
      selfId.includes('password') || selfId.includes('pass') || selfId.includes('pwd') || selfId.includes('mpin')
    ) {
      if (!selfName.includes('user') && !selfId.includes('user') && !selfName.includes('cust') && !selfId.includes('cust')) {
        return 'PASSWORD';
      }
    }

    return null;
  }

  function isInputFilled(input) {
    if (!input) return false;
    const val = typeof input.value === 'string' ? input.value.trim() : '';
    if (val.length === 0) {
      if (input.dataset) {
        delete input.dataset.tpFilled;
      }
      return false;
    }
    return true;
  }

  function clearInputFilledState(input) {
    if (input && input.dataset) {
      delete input.dataset.tpFilled;
    }
  }

  var activeFloatingPill = null;

  function removeFloatingPill() {
    if (activeFloatingPill) {
      activeFloatingPill.remove();
      activeFloatingPill = null;
    }
  }

  function showFloatingPill(target) {
    if (!isVaultUnlocked || !target) {
      removeFloatingPill();
      return;
    }
    const fieldType = classifyInput(target);
    if (!fieldType) {
      removeFloatingPill();
      return;
    }

    if (activeFloatingPill && activeFloatingPill.dataset.targetId === (target.id || target.name)) {
      positionFloatingPill(target);
      return;
    }

    removeFloatingPill();

    const pill = document.createElement('div');
    pill.className = 'cv-floating-pill';
    pill.dataset.targetId = target.id || target.name || '';
    pill.title = 'TetherPass Autofill (Alt+V)';
    pill.innerHTML = `
      <span class="cv-pill-icon">🛡️</span>
      <span class="cv-pill-text">Autofill</span>
      <span class="cv-pill-kbd">Alt+V</span>
    `;

    pill.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!isVaultUnlocked) {
        removeFloatingPill();
        return;
      }
      target.focus();
      handleInputInteraction(target, true);
    });

    document.body.appendChild(pill);
    activeFloatingPill = pill;
    positionFloatingPill(target);
  }

  function positionFloatingPill(target) {
    if (!isVaultUnlocked || !activeFloatingPill || !target) {
      removeFloatingPill();
      return;
    }
    const rect = target.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) {
      activeFloatingPill.style.display = 'none';
      return;
    }
    activeFloatingPill.style.display = 'inline-flex';

    const pillRect = activeFloatingPill.getBoundingClientRect();
    const hasRoomInside = rect.width > 160;
    const top = window.scrollY + rect.top + (rect.height - pillRect.height) / 2;
    const left = hasRoomInside
      ? window.scrollX + rect.right - pillRect.width - 6
      : window.scrollX + rect.right + 6;

    activeFloatingPill.style.top = `${Math.max(0, top)}px`;
    activeFloatingPill.style.left = `${Math.max(0, left)}px`;
  }

  function requestSuggestionsForInput(target, fieldType, force = false) {
    if (!isVaultUnlocked || !target || (!force && isInputFilled(target))) {
      removeDropdown();
      return;
    }

    chrome.runtime.sendMessage(
      { action: 'GET_AUTOFILL_SUGGESTIONS', payload: { fieldType, domain: window.location.hostname } },
      (response) => {
        if (!isVaultUnlocked || !response || !response.authorized) {
          removeDropdown();
          return;
        }
        const isStillTarget = (target === activeInput) ||
                              (document.activeElement === target) ||
                              (target.matches && target.matches(':focus'));
        if (!isStillTarget) return;
        if (!force && isInputFilled(target)) {
          removeDropdown();
          return;
        }
        renderDropdown(target, fieldType, response, force);
      }
    );
  }

  function handleInputInteraction(target, force = false) {
    if (!isVaultUnlocked || !target || target.tagName !== 'INPUT') {
      removeDropdown();
      removeFloatingPill();
      return;
    }
    clearInputFilledState(target);
    if (!force && isInputFilled(target)) {
      removeDropdown();
      return;
    }

    const fieldType = classifyInput(target);
    if (!fieldType) {
      removeDropdown();
      return;
    }

    // Immediately suppress browser native autofill so browser password manager does not hijack
    suppressBrowserAutofill(target);

    activeInput = target;
    requestSuggestionsForInput(target, fieldType, force);
  }

  // Handle focus on fields
  document.addEventListener('focusin', (e) => {
    if (!isVaultUnlocked) return;
    handleInputInteraction(e.target);
    showFloatingPill(e.target);
  });

  document.addEventListener('focusout', (e) => {
    if (!isVaultUnlocked) {
      removeFloatingPill();
      removeDropdown();
      return;
    }
    setTimeout(() => {
      if (document.activeElement !== e.target && (!activeDropdown || !activeDropdown.contains(document.activeElement))) {
        removeFloatingPill();
      }
    }, 250);
  });

  // Global Keyboard Shortcut: Alt+V triggers TetherPass autofill anywhere ONLY WHEN UNLOCKED
  document.addEventListener('keydown', (e) => {
    if (e.altKey && (e.key === 'v' || e.key === 'V')) {
      if (!isVaultUnlocked) {
        // ACT AS COMPLETELY DEAD: do not intercept, do not prevent default, do not show any UI
        return;
      }
      e.preventDefault();
      e.stopPropagation();

      let target = document.activeElement;
      if (!target || target.tagName !== 'INPUT') {
        const inputs = Array.from(document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"])'));
        target = inputs.find(inp => classifyInput(inp) !== null) || inputs[0];
      }

      if (target) {
        target.focus();
        showFloatingPill(target);
        handleInputInteraction(target, true);
      }
    }
  }, true);

  window.addEventListener('scroll', () => {
    if (!isVaultUnlocked) {
      removeFloatingPill();
      return;
    }
    if (activeFloatingPill && activeInput) positionFloatingPill(activeInput);
  }, { passive: true });

  window.addEventListener('resize', () => {
    if (!isVaultUnlocked) {
      removeFloatingPill();
      return;
    }
    if (activeFloatingPill && activeInput) positionFloatingPill(activeInput);
  }, { passive: true });

  // Handle click on fields (triggers suggestions even if field was already focused)
  document.addEventListener('click', (e) => {
    if (!isVaultUnlocked) return;
    const target = e.target;
    if (target && target.tagName === 'INPUT') {
      clearInputFilledState(target);
      if (isInputFilled(target)) {
        removeDropdown();
      } else {
        handleInputInteraction(target);
      }
    }
  });

  // Handle typing, clearing, cut, change, and pasting in fields
  ['input', 'change', 'cut', 'paste'].forEach(evtName => {
    document.addEventListener(evtName, (e) => {
      if (!isVaultUnlocked) return;
      const target = e.target;
      if (!target || target.tagName !== 'INPUT') return;

      clearInputFilledState(target);

      // If text box now contains text/credentials, dismiss suggestions immediately
      if (isInputFilled(target)) {
        removeDropdown();
        return;
      }

      // If text box is empty, and user is focused on it, re-trigger suggestions immediately!
      const isFocused = (document.activeElement === target) || (target.matches && target.matches(':focus'));
      if (isFocused && (!target.value || target.value.trim().length === 0)) {
        handleInputInteraction(target);
      }
    });
  });

  // Listen for Backspace/Delete clearing
  document.addEventListener('keyup', (e) => {
    if (!isVaultUnlocked) return;
    const target = e.target;
    if (!target || target.tagName !== 'INPUT') return;

    clearInputFilledState(target);

    if (isInputFilled(target)) {
      removeDropdown();
      return;
    }

    const isFocused = (document.activeElement === target) || (target.matches && target.matches(':focus'));
    if (isFocused && (!target.value || target.value.trim().length === 0)) {
      if (!activeDropdown) {
        handleInputInteraction(target);
      }
    }
  });

  // If a field is autofocused on page load (e.g. GitHub username or 2FA):
  if (isVaultUnlocked && document.activeElement && document.activeElement.tagName === 'INPUT' && !isInputFilled(document.activeElement)) {
    handleInputInteraction(document.activeElement);
  }

  // Close dropdown on outside click
  document.addEventListener('mousedown', (e) => {
    if (activeDropdown && !activeDropdown.contains(e.target) && e.target !== activeInput) {
      removeDropdown();
    }
  });



  // Intercept ArrowDown, ArrowUp, Enter, and Escape in capture phase
  // so browser native password manager (Google Password Manager) DOES NOT hijack!
  document.addEventListener('keydown', (e) => {
    if (!isVaultUnlocked || !activeDropdown) return;

    const rows = activeDropdown.querySelectorAll('.cv-item-row');
    if (!rows || rows.length === 0) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();

      selectedItemIndex++;
      if (selectedItemIndex >= rows.length) selectedItemIndex = 0;
      updateRowHighlight(rows);
      return;
    }

    if (e.key === 'ArrowUp') {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();

      selectedItemIndex--;
      if (selectedItemIndex < 0) selectedItemIndex = rows.length - 1;
      updateRowHighlight(rows);
      return;
    }

    if (e.key === 'Enter') {
      if (selectedItemIndex >= 0 && selectedItemIndex < rows.length) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        rows[selectedItemIndex].click();
        return;
      }
    }

    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      removeDropdown();
      return;
    }
  }, true);

  function removeDropdown() {
    restoreBrowserAutofill();
    if (activeDropdown) {
      activeDropdown.remove();
      activeDropdown = null;
      selectedItemIndex = -1;
    }
  }

  function renderDropdown(targetInput, fieldType, data, force = false) {
    removeDropdown();

    // Guard: do not render if input already has credentials / value unless explicitly forced
    if (!targetInput || (!force && isInputFilled(targetInput))) {
      return;
    }

    // STRICT AUTONOMY GUARD: If locked or not authorized, NEVER render any popup or notice!
    if (!data || !data.authorized) {
      removeDropdown();
      return;
    }

    // Only render dropdown if there are matching items for this field type
    const hasCardItems = ['CARD_NUMBER', 'EXPIRY', 'EXPIRY_MONTH', 'EXPIRY_YEAR', 'CVV', 'CARD_HOLDER'].includes(fieldType) && data.cards && data.cards.length > 0;
    const hasBankItems = ['ACCOUNT_NUMBER', 'IFSC'].includes(fieldType) && data.bankAccounts && data.bankAccounts.length > 0;
    const hasBankLogin = ['USER_ID', 'PASSWORD'].includes(fieldType) && data.bankAccounts && data.bankAccounts.some(b => b.userId || b.loginPassword);
    const hasLoginItems = (['USER_ID', 'PASSWORD', 'TOTP'].includes(fieldType) && data.passwords && data.passwords.length > 0) || hasBankLogin;

    if (!hasCardItems && !hasBankItems && !hasLoginItems) {
      removeDropdown();
      return;
    }

    suppressBrowserAutofill(targetInput);

    const rect = targetInput.getBoundingClientRect();
    const dropdown = document.createElement('div');
    dropdown.className = 'cv-autofill-dropdown';
    dropdown.style.left = `${window.scrollX + rect.left}px`;
    dropdown.style.top = `${window.scrollY + rect.bottom + 6}px`;
    dropdown.style.minWidth = `${Math.max(260, rect.width)}px`;

    // ── Header ──
    const header = document.createElement('div');
    header.className = 'cv-dropdown-header';
    const brandLogoHtml = `<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABoKSURBVGhDlZpnc1zXneZhWYEkCBCpu4HOOaJzTkA30A2gATRyTgRAEiRIgAQDwACQFClSpBhEUpREkQoUpZFGluWRbI89LstpxjOO42yvZ2fXW1vlqdp9sb1VW/4Av617QFL21OyLffH0vd333nOe55x/Oud2WYMl8AelLVRSWoMllS1UUtvDJbUjXNI4IiW9K1oyeOIlozdZMvnSJZO/qWQONJcswUzJGtqELdxSskVaS3YJ0ZyA4/8BcT3yCK0lW7i1ZA1lRXvmYLNo2+RPl4zehOhX3xgr6ZzRksYR3uRlDwmOSmuoJHFuMPv/UKa0Bv6kcUTQOMJonRF0rhi6xhgGdxyjJ4HJm8Lsb8ISzGANZbGFW7BHW3FEczhieZzxNlzxdhoTD5HsEHD/Ozz6vTEhYfNe6TlnLC/askdaRdtSH5ZAE2ZfGqM3KXjoG+OCl9YZReOMoHaEBZSWwJ8kAZI61PYQWkcYnSuK/s8F+NLo3Ak0rjhadwKDN43J34w5mMEczGIJtWCL5LBH8zhibTglUomOhyjgShQeHjvENUesHXusTdxvDbeK56V2jP5mDN7Uw76kQYxj8iYFB4mPBGmApYGWuEposARKjwVIF/6SfBKtK4YlmCU/MM304lH2r53l8MZFVs9d4cSF66w/f4MzL7zE+euvcOHmHS69dI8rr7zB1Vff4tqd+1x/7W2u332widfe5sqrb/HCy2+I+y7cuMOzV2+zcekmJy9cZ+3cFdH2/tUzoq98/xTWYDMaZ/SxCImfJOKRAIl7WcN/KCCB1hUl0z3G4pF1Fo+dZnLfUQZnl+mdPrCJmSX6dy4zMHeIoV2HGdlzhFGBo4wuHGN0YZWxfcc3sVfC2mNI14d3H2FwfoX+nQdFWwLTBxiYXWZ87xEWDq+z9/BJssVRYTZ/Pgt/IeDRDGgdkv1HMYibonQMzTA2v0Q0P0Rjuogv008wN0ykfYxYxzjxzkkS3VMku6dJdE2R6p2jdfwA3XtOMHzoPJOrLzC7foO5jZtMH7/CyKHz9CycJD+xTLpvXjyX6p4mWZzB1zpMMD9CtGOMUG5Y9NWYKhLNDzI2f4DC4IwgLmZB8oNHPvBoBh45sN4VRWUP0dw5RMfgDLZYO75sH8HWQUL5YaLto8QL4yQ6J0h2TYhjdngvvYsbTKxeZvbUVXadusLC+hUWN65w8NwNDp2/wYHTV9m7fpXd61eYP3mFqdVL9C1ukB3ZR7J7irVz15hYPE4gN0isY4xwflj06c30CQ7tg9NkuoZR20KfmdFfCog8dhBXpJXC4DTWSB5Pcw/eTC+BbD+epiLu5j682QF8LQOEC5N0711nYOkMAwvHmNy/yvKJ8zz34ivcev0B73z4MXcfvM9b73+R9770VV69/z7PvfgqB09dYGbpBAMLq/QvnWFy+RT/+//8iSu3X6e5dwZnslv0FWjpx5fpExwskZzg1BjLPY6WEmcp9G8KcG4KaLAGaSmOE8wWsccLuNPd2GMduLKDtMwdZ/DoC4yfuM7s2ZfoX7lIfnyR4Z2LrJ6+yJvvfoGvfuPbfOf7P+QHP/kZn3z9U1bWL3Dg2AZf+/S7/OzXv+MHP/0F3/j23/Pa2+9z8twL9E8u0NYzwsraBrP7Vth75hZ9KxfJ7TqBKzOIJ92Nu2mTSzDTTa53DKUtKLhKUNmCmz4gCdA4Qhg8STpH5rGEW3HEC7hSXfTNHGD6xFXO3HqbK6/c58rL95lbPkHbwBRTe5a49tJdPv3eP/Hjn/+Gn//m9/z6P/0rDz74mMmFFXqn99M/tYfC8DRXX36dP/7P/8W//vc/8sN//iXvf/Rl5vcf5va9t2kvDqLUWjh8+jLPvfgaZ2+8wcyzL+NsGaIx2Ykz0Sk4FYZ2itAqhfvHAqQPSYDS4qcx3kbb0CzGQFbEaGfbFCO7D4tR6h2Z5sjpC8wsHiGZ7+HQiTOsn7/MOx9+mb//0c/5x5/8gp/84rf8+vf/hTsPPhABQIooQ7OLdI/Ns+fQCfYfOsK7H3yRX/zuP/PT3/wLH37l77j12lt4wmlkSgNNHf2cuXyD567cYv3KK3Qvn8MWbceZLAhObQPTuBN5yfaFAKWYgYcC6k1eAs3dZIoTGPwZjP4mPN276BhboKm9B1+smZaeUXI9wxxaW2ffynFefvM9Pvrat/jyN77LD3/2WyHiw4+/wur6Odp7R+ganadndJZ4tkBb3xh6m5sqmYpgNMlzl68J37h59wEzew/SPzFHa/cwTR0DrF+8zukL15g9cwtncy/2WDuGQIaW3glC2S4UJq/wgU0TeihAYXQTauklVRhB521C35jAlOwlkuvDHYpjcwfJtBfZvf8Q+1eOc/H6He791Zd4668/5ivf/AcuX3+JYCSBQqWnXq1HobOwsHKCA4dPEEy10jU8w8uvv8O7H35CoX+Mipp6AuEEF6+/zI2777D/6Dr7j54kUxgg1zPK2YvXmN14EXfrEPZoG8ZAhubuUaKtReSGxs8ESB9SSJLpG4m09hFvH0TrTkppmmT/PPuPn2dldZ19B49y5dYdbr/+gBuvPeD2m+9z8+47vPn+xzx39RZak435A0eFXzQV+km097Pn8DrLq+u0D04xMLOXW3fv8y//7d/44c9/y/VX3sTcGEBer2Zh6QjLa2eZ3LPM0tFTJFq7aeka5Itf+zbf+/EvhCPrvWnSncPEWovI9M6HYfSRAHuIOr2LcK6PaNsASnsUWzTP8tUHnL1+jxfvPODm6+9x8+67vPTGe1y/8zbXJIe+/Savvv0hPUMTDM8s8Lff+kcu37qDJ5ZB7wwyML3A+NxebL4okeZ27j14n1/9/r/y6fd/zEdf/zaXX7qHP5ahYkcNgxM7mV9eo290huGpOfrHpvngo0+49dqbeJJt6DxpUh1DxFp7qNPZUduCjzKxKKOp1TkJ5/oJt/Si87fQ1D/P8qU3WL/8ChdfvMOlm3e5dOseV26/weVb97h863VxvPbqfYandnHi3At88Mnf8eVvfIfbr73F8dPnuHb7LjdffZ2TZ5/j3v13+dHPfsVPf/k7/vZb/8DNe++w8fwNltbOYPOEqZU1MDS1m97xeZYPr3L11h0c/gT1RhfB3ACWSBvxfD+x1l7qtI8EPAyjKluQWq2DcH6AQHMX9lQv3XNHGTl4jvlD68wsHGJi1xL7Dp/iwvU7nL/6MueuvizOX3jpdaZ27Wf1zEXe++irfPN7P+DL3/gW7374EVdfeYNrr7zBOx9+ia9887t8/6e/4tvf/xHv/83XOH/1NvuOnGLn/iMMTi8gU+owWl3MLh4m01akok7Nk1t3YHAGmV67jCs7QCRbJJ7ro05rEwKkHCYSmRSWajQOwm1D+Jo6sSaLDB44LUJVjcpCRa0KVzhNvdZMKt8tqsl3v/Axl26+JsSMzezi9KUb3LjzFkeOHuXQwYNsnDjG3MIBZncvcHZ9lSOHD7F/6QDPv/gyl2/d5fD6OSYXDjK15yCXb7xC/8Qs2ypracp3MbHnIL5YBq3FjdrcyPDyaWypIqFMF/G2fuo0NlRWPw1W32cCqjV2Ih0j+NIFLIku2mePorGHabD4SRRGmNp7GEWDBrnayOLqsxw9vsHffPIV3njwHvsOrbGwfIzOfAsH5ka5sDLFqb2j7Nq9hwP7FriyOsPZI7tYmJugp6OVqV2LzOw7xPGNc9x/8B4nNs4yvWcJdzCBxeVjZG6R4shO0vkiFk+MzNgitmQXgaaCCDK1aqsQUG+RBFj8JYlktdpOrDCGJ9UhBMQH9mEPtZAsjDCycIy27iG2llfiT7Qyu3ScSHMHua5+nr96i5VT54kHvaSCXg4MNHHtYJHDi7s5cHiNlaNrrC7Nc2JPD3v6m2mKBkhGgsJULly6Slf/MPGWdnpGdpLvGcUdTgviE7uXGJtbJNrcTqx3DmuiC1+qXQxmjdqK0uJDYfaVyuofCdDYiXdN4E62Y4p1EuieE6Gwb3aZ6QPHCSezbK+qEwuNkfllCoNTxFs66RxfINPWLUZxY3mOvuYQuw8c4bUHX+De3bu8du8edx58yMKBFSbyXjYOTHDqzHlyhT76Z/aS7exjYGIXoUwrobYCvnyHiEwTe5bZuW+F9p5hQl2TmOIdeBM5kl2jQkDDYwFmf6ne7NsU0D0p1qraYA5jqo+W3nHmjj7L+J4VkchUBrvIrr2TeygMTNE7tZddx84ScNmIB3ycOnWKKy/eYP3sRW6v7eGf7q/z3dc3uLg0x9rGeV64foP1U+ukIyGCbif71s4yMruPsbl9TF26xPCRVVq6B7D7YvRP7mbPoTX6x3fizw+iC7bgSeRIFcepUduot3hRmHylMumj3ux9KGBKLLIVziRnrt/l2UvXaeufEMlJrtRjdPhoH5ika3iWgvT7wZPsO3Icr0VPt1+N36Klb2Iv52fa+c39ef7Hz97m5+8t8empMMeGMqL69BmVZJ0qgo12Dq5tML5nmVC2k+Z9K6RHZ2lq68XmidA5OM2u5WMMTc3jjOVQWEN4EnlSxQmqhQAPCrNHEuAtKcyeTQHFKbE7oHan+MInX+feWw84eOQ4z125yeKhNQ6ffJYzz1/nyq27vHj7LmdfepOVtRPsHmpjoslMcyrJ2OQ8Hyy6+ON31vi3393n3uEAXz8b4NUJM5PT86SiEeazZvKRRo4cP8XYnkNEW7qEbyVyRTJdQxgdftr7xphfOsrQ9G7soWbqjF7c8dZNARqrECA3N5bK5CZPSWHyUPVYQAsKa5hA+xi+TDcWbwyjN4E/lRMdpdsHSHZIMblA58wSqxtn6Up6GYgZCPl8FAfGuDVi5Jd3c3ztdhdvH3PzuzdauTtloW9wjKjfw8EOC90pLydOn6U4sRtvPEuktZtYrij6MDr9ZDsHRYht7R7C7E9Sa/DgiraQ6B6jSm2VRv/PBBglATZi3ZPYQhlk1giNbeOYglnkeqcoC8ora6iRqXDHssRzPYTSbSSLkywdP0NzyE2bo5bdQx2M7TrIZLOf270KPt4I8ukLSb60R8vBYpTxXcvsGszT7ZHRkgixunGOdMcAnmgToUwnidZOERhMrgDtfeMMz+2nvW8Uky9FncmPM9xMrDBCtcoqik+50VUqkxs9JbnBTZXKRqQwjiWQRulpQhftEDdFOidFCtca7eyorSecLZLrnaCprQ9Pqp3WgZ0s757h1MoiZzZOEwoniMYzHOpr5ktHo3x0OMzJ0SyZTI5IKMzJ42usHlrkwO5pOgYmsXmjhJs7CKbbiGQ78aZyWFxBca04Nkcy14013o7SncQaSBHtGKZKZdkUYJAEGFwlqTzdobQSbB/B5E+h9rdgaupHbfOLRX2mdxpXIMa2iir86TZae8aJtXSRLQyQbB9g6cgJin0DeFQ1BFWVyOtVRNJ5ZqZmmN05SzLTjkalxtOwHY+6hkJ3n1hGptuKhFMtmBrDaO2NqOweGhxe3KGkCB7ZriH88Qy2dDdafxaLL0G4bZAqlRmFoRG5XghwluR6FzuUZvy5QbGdp/ZlMKf7aDC5xeZSJD9ALNNBVY0Cg+Rgg9PsXT7Ks89fJT84jS+RY7S/iLZmOx0uBb1+Fca6SnIdPXQX+7ApKpmKqcnaFejltUwM9hFItIgye23jnChF7IEEaqsPhdZKNNNOur2PYDqP2RXA0dwnBJi9cQKtfVQpJQEu5HpHqUymd5ZkOgc7GkxiB0LalVN5mvC0T7BDYcDmjWw6T2sRnclBvdYi7Hxp9Qyxtn4MrjA76pQUR2Z4dv04xVSQNreGhKGaieFhZkeHiGh20GRXsjTSxvOnTzA4PkuNQoNKbyeS7WJh5SS9w9Nsq6hBY7TR2j0iaqFAIotMZSRUGEfjy2B0R/E1d7Oj3iR8c1OAzrEpoN5IY7oLnSuCsjFFqGsnlQ0mMp0DhBLNdPQM0jM4RirfQ6yliCOSxegKY/FEkdVr2F5TT3F8N3fv3ePK2TUWx3s4tHyQw4cOsm+8lxdOH+P+W28ytvsgtfV6DFa3yCs6SyPuSAaLy095RRXxTDtN7X3ozA5UBhvl1QrSAzvReJswuCKiUpC4SgJkOnuprE5nL0n1dWW9EUe8HY20adqYwp0bITe9wvTBdXqHJxmemmdwardY0LujGUFcwBulXmuiXmOiweAgXhjm2HMvcvftv+Ltv/6QB1/4iPvvf8DG1VeJFUZxBpJEklkRaWy+GHZvFKsrwNbtVbh8YWE67nCK4tAk6Wyejt5R8tPLNDQm0TmDOKItVNYbqNM6pKq0VFaneSTAgDXcIupsmTWMs6mX3gPPkh/bS1iKEM2dIlJICccVSmP3J7D54uKoMzvRWz1YvRGMNg8KtQmzJ0pT3zT54Xks3jgNWgsmhxe93Uv38BTecIrGUBpvJE1FtQyN3ky20I8/nqVGZSZanKE4OM6lay+x8txtKrWN6Ox+bMEmKhWSADu1aluprFZtLdVqNgVIW+lqW4AdajumYI6u/efIDs4RSLYSbuogmMoLAZ5oRoiQIM2G3RPC5Y+RyHVjcfqprJZTXl1Pa98UHb1jlO+QUVGtwOWP444040u00jM8RaM/SnVdPSqNkZZCP9FMgXqdlVqVmSe3VOLNDxHrGhdCpXWJ1ubH5IlTIddTq7F9JqBGYxOqpBcbUplapbLiSrTjzQ2LlxJ6R0DA7E1gaIyIiOFLtOCJZfHGWwilcySbWxkYmyaabKaiuo4dcg1d47vpHpmmpsFAtUIrtmY6h6ZFdpeqWb3JisliJ9fZTyxbQG1yojI3UlOv4/NbKnEVpgn378LqjVKtMqO2etG7IpsC1FZJVKmsRmUtSeWp9KO076iUygqlGU+6C0O4TWQ/yb7Lyp7gme21bK9TUV5Tj9EVJNTURiCVJ9xcoGtwkqld++gdHscbjKEx2sUmlDRjVTI1dWoTsWwnueIwVXX1yHU24VedPUPEsx2CfIPBSb3OxjMVNcLGnZ0zqBvjOIMp4bhqiwetI0iFXPeZgGqluVQtLRvlerH6Upo9VCgMOCKt2DPDaF0RVCYnT2/ZTkVNA9UNBupUZiplGkyeCJFMB7FMJ5nOIYpj8xRH54k0F7D6kzTYQujtfmobdJRX1VEjUyJvUONs9Al/SOV7yXf106A2oLe6UWjMPF1eQ73BhdYexDuwF4O/WSzuJdJqaYlp9YrzGrUFiftnAhR6anUOVBYP5XUa8Z7AnOhC70mgNrt5plKGZGpbq+upqFOi0NupkKnROAJEcz0ia0r1S3v/BN6YFLNjqJ0xsSi3OL3Ekk0UegYZndnNyOyiEFird5HvHcXq8FBd18DT22tRmr1YPHF8HeNCgN2fxuKOsK1WLQTI9Q7BVTKpaqWpVFbVYC5JtYXkxNLISzOwXaYVm0fS6FdpHZilTBjtZHu9JNTIk9tqeLq8WkSLKqUJucmNt6WfzOA8Tb0T+NId6Jxh6sWMNpLrGmL/sdMMze6nc2wPueFdKK1etlYp8CXb6OobRmv1IDf5cISaiRSnSc0fF4urYCqHwuAUg6qxuqms1wuukoCqBiHAVJJsXvpxa41KSg7UqEyUSyJ0TmpUVnZoXXj79+Lr3Ys9P4E5M4I60kGl1kmFXCsak2ZH6YxiTUjLwhEC7aP42jaPndNL9Ow6QlPfjCjXpVGs01hFplfobHT0DHPu+l0ivbtIzxymZWEdX1M3oWQrZneE8jotdSoTSqODrTVKwVUauKoGY6msst5YksoIaVqkadpWq6JebxcPbalRidWPVNRJr3capbcmhSka2yZx5CeQ20JsqahjW41KVIgyQ6OoEtWOEEZfClOgCZM/jcGXEgFCZfXRYPGKvc3yWrUIldLLC1+2h1imQGpgnuTAPNGWIpGmNhH5JN+ULEJy8vJaleD3SEBlvaFUVlFvKO1oMArHkKbpqUo5FTKNELG1Vs3TVQ1idPWNEWyBFK5IBlc0K8Kp0RNH74mjtAWo0bmo1ruR2UKoPGnU3jQ6fzNafzMaXxNafwZlY4I6k1dsYyrtQdSOICpnBHMkJ0xWyuxSWG6MZlBZvcIKJE5SENkh1/JUpYxymYZKhR6JszT4ZRUKQ2mHZP8PBWypbuCJbTVUyrUojS6q6g08XVXPlho1O1RWavWN1Brc1OpcyC0BZI8RpNYSpMYcoNoUoELjYqvCJLBd5aDaHKDWEhJZXmYNbd5v8lGpdrBVpqdK46BG5xQrw3KZjq3VKpHQdFYPVQodT2yrZmtNA9sfCzAgDX5ZhUJfEg4sBGiFHzy9Q87ntlSxtVqJ0uxGaw/QYGxEppWyn0U0LB2rJTusN4oGKxQ60UaFTCemfLt0Ltc/xOa1SglS5wq9OErfxb0yrTivURqRS9uGFo9YI0ghWDIbicszO+Rsq1Vu3is9K4KOvlRWLteVJPuXOpAuSn7wTJWCJytkfG5rFZ/bVsN2mR5p3Sy9R5DKbYM3KezbEspilf4iIP1VIN62+XY+WcCZ6sSV7qKxqVtAOndJv6UKuJIdomiU3tRLzxt9afSeJHqpXY/0l4IIDSIX6YUlPLG1mqcrZWypVrCtTvWXAuS6/0iAhi01DWIWJBFPbq8T01e2teohqinbVi2EfW5bLU+US6gT+Px22UPI+XzFv8N2GU9IeHiv9NxmG38Gqe0tVZRt2SH6fLK8lqcq6nimSs62mgbK69SCo5hNhR6Je9l2me5Pm2okb980I2kWNkUohFM/WSl7DMmRJAhxAnXi+Oj3v7z2EI+e/7P7xXF77cPvDyF93/7oXMZTFTKerlKwtbpBjL7k1MI0JXNVGCS+f5IE/KFcri+Vy3SlbTJNaZtMXdpWqy5tqVWWtlTXl56qUpSerJSXnqyQbaLyEeTi+FSl/P8bj5593OZj1D3EZh9PV8lLW6oVpS01DaVtdUrBrVymKZXLJehK22WaP/xf4xK/8mDR5twAAAAASUVORK5CYII=" class="cv-brand-icon" alt="TetherPass" />`;
    header.innerHTML = `
      <div class="cv-header-left">
        ${brandLogoHtml}
        <span class="cv-title">TetherPass</span>
      </div>
      <span class="cv-status-tag ${data.authorized ? 'cv-authorized' : 'cv-locked'}">
        ${data.authorized ? '● Unlocked' : '🔒 Locked'}
      </span>
    `;
    dropdown.appendChild(header);

    // ── Content ──
    if (!data.authorized) {
      // Locked state: Must authorize from mobile application
      const lockBox = document.createElement('div');
      lockBox.className = 'cv-locked-notice';
      lockBox.innerHTML = `
        <div class="cv-lock-icon">🔒</div>
        <div class="cv-lock-text">
          <strong>Mobile Authorization Required</strong>
          <p>Open <em>TetherPass</em> on your phone → <strong>Settings → Browser Extension</strong> to unlock autofill.</p>
        </div>
      `;
      dropdown.appendChild(lockBox);
    } else {
      const itemsList = document.createElement('div');
      itemsList.className = 'cv-items-list';

      // 1. CARDS (If card field or general payment)
      if (['CARD_NUMBER', 'EXPIRY', 'EXPIRY_MONTH', 'EXPIRY_YEAR', 'CVV', 'CARD_HOLDER'].includes(fieldType) && data.cards && data.cards.length > 0) {
        data.cards.forEach(card => {
          const itemRow = document.createElement('div');
          itemRow.className = 'cv-item-row';
          const last4 = card.cardNumber.slice(-4) || '••••';
          itemRow.innerHTML = `
            <div class="cv-item-icon">💳</div>
            <div class="cv-item-info">
              <div class="cv-item-title">${escapeHtml(card.nickname)} (${escapeHtml(card.cardNetwork)})</div>
              <div class="cv-item-sub">•••• ${last4} | Exp: ${escapeHtml(card.expiry || '••/••')}</div>
            </div>
          `;
          itemRow.addEventListener('mouseenter', () => {
            const allRows = itemsList.querySelectorAll('.cv-item-row');
            selectedItemIndex = Array.from(allRows).indexOf(itemRow);
            updateRowHighlight(allRows);
          });
          itemRow.addEventListener('click', (ev) => {
            ev.stopPropagation();
            ev.preventDefault();
            removeDropdown();
            fillCardDetails(targetInput, card, fieldType);
            removeDropdown();
          });
          itemsList.appendChild(itemRow);
        });
      }

      // 2. BANK ACCOUNTS & IFSC (Only for bank account / IFSC transfer fields)
      if (['ACCOUNT_NUMBER', 'IFSC'].includes(fieldType) && data.bankAccounts && data.bankAccounts.length > 0) {
        data.bankAccounts.forEach(bank => {
          if (bank.accounts && bank.accounts.length > 0) {
            bank.accounts.forEach((acc, i) => {
              const itemRow = document.createElement('div');
              itemRow.className = 'cv-item-row';
              itemRow.innerHTML = `
                <div class="cv-item-icon">🏦</div>
                <div class="cv-item-info">
                  <div class="cv-item-title">${escapeHtml(bank.bankName)} ${acc.accountNumber ? '• ' + acc.accountNumber.slice(-4) : ''}</div>
                  <div class="cv-item-sub">A/C: ${escapeHtml(acc.accountNumber)} ${acc.ifscCode ? '| IFSC: ' + escapeHtml(acc.ifscCode) : ''}</div>
                </div>
              `;
              itemRow.addEventListener('mouseenter', () => {
                const allRows = itemsList.querySelectorAll('.cv-item-row');
                selectedItemIndex = Array.from(allRows).indexOf(itemRow);
                updateRowHighlight(allRows);
              });
              itemRow.addEventListener('click', (ev) => {
                ev.stopPropagation();
                ev.preventDefault();
                removeDropdown();
                fillBankAccountDetails(targetInput, acc, bank, fieldType);
                removeDropdown();
              });
              itemsList.appendChild(itemRow);
            });
          }
        });
      }

      // Bank Netbanking Login (ONLY if current website is specifically that bank's website)
      if (['USER_ID', 'PASSWORD'].includes(fieldType) && data.bankAccounts && data.bankAccounts.length > 0) {
        data.bankAccounts.forEach(bank => {
          if (bank.userId || bank.loginPassword) {
            const itemRow = document.createElement('div');
            itemRow.className = 'cv-item-row';
            itemRow.innerHTML = `
              <div class="cv-item-icon">🔑</div>
              <div class="cv-item-info">
                <div class="cv-item-title">${escapeHtml(bank.bankName)} Login</div>
                <div class="cv-item-sub">User: ${escapeHtml(bank.userId || '••••')}</div>
              </div>
            `;
            itemRow.addEventListener('mouseenter', () => {
              const allRows = itemsList.querySelectorAll('.cv-item-row');
              selectedItemIndex = Array.from(allRows).indexOf(itemRow);
              updateRowHighlight(allRows);
            });
            itemRow.addEventListener('click', (ev) => {
              ev.stopPropagation();
              ev.preventDefault();
              removeDropdown();
              fillCredentials(targetInput, bank, fieldType);
              removeDropdown();
            });
            itemsList.appendChild(itemRow);
          }
        });
      }

      // 3. WEBSITE PASSWORDS & 2FA TOTP (Matching current domain)
      if (['TOTP', 'USER_ID', 'PASSWORD'].includes(fieldType) && data.passwords && data.passwords.length > 0) {
        data.passwords.forEach(pwd => {
          if (fieldType === 'TOTP' && !pwd.totpCode) return;
          const itemRow = document.createElement('div');
          itemRow.className = 'cv-item-row';
          const totpBadge = pwd.totpCode ? `<span class="cv-totp-badge">⚡ ${escapeHtml(pwd.totpCode)} (${pwd.totpSeconds}s)</span>` : '';
          itemRow.innerHTML = `
            <div class="cv-item-icon">${fieldType === 'TOTP' ? '🔐' : '🌐'}</div>
            <div class="cv-item-info">
              <div class="cv-item-title">${escapeHtml(pwd.nickname)} ${totpBadge}</div>
              <div class="cv-item-sub">${escapeHtml(pwd.username)} ${pwd.website ? '• ' + escapeHtml(pwd.website) : ''}</div>
            </div>
          `;
          itemRow.addEventListener('mouseenter', () => {
            const allRows = itemsList.querySelectorAll('.cv-item-row');
            selectedItemIndex = Array.from(allRows).indexOf(itemRow);
            updateRowHighlight(allRows);
          });
          itemRow.addEventListener('click', (ev) => {
            ev.stopPropagation();
            ev.preventDefault();
            removeDropdown();
            if (fieldType === 'TOTP' && pwd.totpCode) {
              setInputValue(targetInput, pwd.totpCode);
              try { navigator.clipboard.writeText(pwd.totpCode); } catch (_) {}
            } else {
              fillPasswordCredentials(targetInput, pwd, fieldType);
            }
            removeDropdown();
          });
          itemsList.appendChild(itemRow);
        });
      }

      if (itemsList.children.length === 0) {
        removeDropdown();
        return;
      }

      dropdown.appendChild(itemsList);
      const initialRows = itemsList.querySelectorAll('.cv-item-row');
      if (initialRows.length > 0) {
        selectedItemIndex = 0;
        updateRowHighlight(initialRows);
      }
    }

    document.body.appendChild(dropdown);
    activeDropdown = dropdown;
  }

  // ── Auto-Filling Logic with Input Event Dispatching ──

  function setInputValue(input, value) {
    if (!input || value === undefined || value === null) return;

    const valStr = String(value);

    // 1. Native Property Descriptor Setter (Required for React 16+ SPAs like Flipkart & Blinkit)
    try {
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      if (nativeSetter) {
        nativeSetter.call(input, valStr);
      } else {
        input.value = valStr;
      }
    } catch (_) {
      input.value = valStr;
    }

    // 2. React Internal Tracker Update
    if (input._valueTracker) {
      input._valueTracker.setValue(valStr);
    }

    if (input.dataset) input.dataset.tpFilled = 'true';

    // 3. Dispatch Full Event Suite for modern frameworks
    input.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
    try {
      input.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, data: valStr, inputType: 'insertText' }));
    } catch (_) {}
    input.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
    input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: valStr.slice(-1) }));
  }

  function getCardNumberFormattedForInput(input, rawCardNumber) {
    const digits = (rawCardNumber || '').replace(/\D/g, '');
    if (!digits) return '';

    if (input.maxLength === 16) return digits;

    const ph = (input.placeholder || '').toLowerCase();
    // Format as 4-4-4-4 for standard card inputs or placeholders like XXXX XXXX XXXX XXXX
    if (ph.includes(' ') || input.maxLength === 19 || input.maxLength === -1 || !input.maxLength) {
      return digits.replace(/(\d{4})(?=\d)/g, '$1 ').trim();
    }
    return digits;
  }

  function getExpiryFormattedForInput(input, rawExpiry) {
    if (!rawExpiry) return '';
    const clean = rawExpiry.trim();
    const ph = (input.placeholder || '').toLowerCase();
    const hasSpacedSlash = ph.includes(' / ') || ph.includes(' /');
    if (hasSpacedSlash) {
      return clean.replace(/\s*\/\s*/, ' / ');
    }
    return clean.replace(/\s*\/\s*/, '/');
  }

  function getAllPageInputs(focusedInput) {
    const parentContainer = focusedInput.closest('form, div[class*="payment"], div[class*="checkout"], div[class*="card"], fieldset') || document;
    const inputs = Array.from(parentContainer.querySelectorAll('input'));
    if (inputs.length < 2 && parentContainer !== document) {
      return Array.from(document.querySelectorAll('input'));
    }
    return inputs;
  }

  function parseCardExpiry(expiryStr) {
    if (!expiryStr) return null;
    const clean = String(expiryStr).trim();
    let m = null;
    let y = null;

    if (clean.includes('/')) {
      const parts = clean.split('/');
      m = parts[0].trim();
      y = parts[1].trim();
    } else if (clean.includes('-')) {
      const parts = clean.split('-');
      m = parts[0].trim();
      y = parts[1].trim();
    } else if (/^\d{4}$/.test(clean)) {
      m = clean.slice(0, 2);
      y = clean.slice(2, 4);
    } else if (/^\d{6}$/.test(clean)) {
      m = clean.slice(0, 2);
      y = clean.slice(2, 6);
    }

    if (!m || !y) return null;

    let monthNum = parseInt(m, 10);
    let yearNum = parseInt(y, 10);
    if (isNaN(monthNum) || isNaN(yearNum)) return null;

    if (monthNum > 12 && yearNum <= 12) {
      const tmp = monthNum;
      monthNum = yearNum;
      yearNum = tmp;
    }
    if (monthNum < 1 || monthNum > 12) return null;

    const month2 = String(monthNum).padStart(2, '0');
    const month1 = String(monthNum);
    const shortMonths = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const fullMonths = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const monthShort = shortMonths[monthNum] || '';
    const monthFull = fullMonths[monthNum] || '';

    const year4 = yearNum < 100 ? String(2000 + yearNum) : String(yearNum);
    const year2 = year4.slice(-2);

    return {
      monthNum,
      month2,
      month1,
      monthShort,
      monthFull,
      year4,
      year2
    };
  }

  function setSelectValue(selectEl, candidateValues) {
    if (!selectEl || !selectEl.options || selectEl.options.length === 0) return false;

    const candidates = candidateValues.map(v => String(v).trim().toLowerCase()).filter(Boolean);
    if (candidates.length === 0) return false;

    let bestIndex = -1;
    let bestScore = 0;

    for (let i = 0; i < selectEl.options.length; i++) {
      const opt = selectEl.options[i];
      const optVal = (opt.value || '').trim().toLowerCase();
      const optText = (opt.text || opt.textContent || '').trim().toLowerCase();

      for (const cand of candidates) {
        // 1. Exact value match (score 100)
        if (optVal === cand) {
          bestIndex = i;
          bestScore = 100;
          break;
        }
        // 2. Exact text match (score 95)
        if (optText === cand && bestScore < 95) {
          bestIndex = i;
          bestScore = 95;
        }
        // 3. Numeric match (e.g. "5" matches "05")
        const candNum = parseInt(cand, 10);
        if (!isNaN(candNum) && (optVal === String(candNum) || optVal === String(candNum).padStart(2, '0')) && bestScore < 90) {
          bestIndex = i;
          bestScore = 90;
        }
        // 4. Token match in text (e.g. "05 - May", "May (05)", "2028")
        const tokens = optText.split(/[\s\-/,()]+/);
        if (tokens.includes(cand) && bestScore < 85) {
          bestIndex = i;
          bestScore = 85;
        }
        // 5. Text starts with or contains candidate
        if (optText.startsWith(cand) && bestScore < 80) {
          bestIndex = i;
          bestScore = 80;
        } else if (optText.includes(cand) && bestScore < 70) {
          bestIndex = i;
          bestScore = 70;
        }
      }
      if (bestScore === 100) break;
    }

    if (bestIndex >= 0) {
      selectEl.selectedIndex = bestIndex;
      selectEl.value = selectEl.options[bestIndex].value;

      try {
        const tracker = selectEl._valueTracker;
        if (tracker) tracker.setValue(selectEl.value);
      } catch (_) {}

      try {
        selectEl.dispatchEvent(new Event('focus', { bubbles: true }));
        selectEl.dispatchEvent(new Event('input', { bubbles: true }));
        selectEl.dispatchEvent(new Event('change', { bubbles: true }));
        selectEl.dispatchEvent(new Event('blur', { bubbles: true }));
      } catch (_) {}

      // Synchronize custom dropdown UI display (Amazon a-dropdown, select2, bootstrap, etc.)
      try {
        const parentDropdown = selectEl.closest('.a-dropdown-container, .dropdown, .custom-select, [class*="select"]');
        if (parentDropdown) {
          const promptSpan = parentDropdown.querySelector('.a-dropdown-prompt, [class*="prompt"], [class*="selected-text"], .select2-selection__rendered');
          if (promptSpan) {
            promptSpan.textContent = selectEl.options[bestIndex].text || selectEl.options[bestIndex].textContent || selectEl.options[bestIndex].value;
          }
        }
      } catch (_) {}

      return true;
    }
    return false;
  }

  function fillCardExpirySelects(container, cardExpiry) {
    const parsed = parseCardExpiry(cardExpiry);
    if (!parsed) return 0;

    let selects = Array.from((container || document).querySelectorAll('select'));
    if (selects.length === 0 && container && container !== document) {
      selects = Array.from(document.querySelectorAll('select'));
    }
    if (selects.length === 0) return 0;

    let filledCount = 0;
    let monthSelect = null;
    let yearSelect = null;
    let combinedSelect = null;

    selects.forEach(sel => {
      if (sel.disabled) return;

      const raw = getElementTextContext(sel);
      const norm = raw.replace(/[-_./]/g, ' ');
      const autocomplete = (sel.getAttribute('autocomplete') || '').toLowerCase();
      const name = (sel.name || '').toLowerCase();
      const id = (sel.id || '').toLowerCase();

      const options = Array.from(sel.options || []);
      const optTexts = options.map(o => (o.text || o.textContent || '').trim().toLowerCase());
      const optVals = options.map(o => (o.value || '').trim().toLowerCase());
      const allStrings = optTexts.concat(optVals).filter(Boolean);

      const monthMatches = allStrings.filter(s => /^(0?[1-9]|1[0-2])$/.test(s) || ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'].includes(s.slice(0, 3)));
      const hasStrongMonthOptions = monthMatches.length >= 6;

      const yearMatches = allStrings.filter(s => /^(20[2-4][0-9]|[2-4][0-9])$/.test(s));
      const hasStrongYearOptions = yearMatches.length >= 3;

      const hasCombinedOptions = allStrings.some(s => /^(0?[1-9]|1[0-2])\s*[\/\-]\s*(20[2-4][0-9]|[2-4][0-9])$/.test(s));

      const isMonthByAttr = autocomplete.includes('cc-exp-month') ||
                            name.includes('expmonth') || name.includes('exp-month') || name.includes('exp_month') ||
                            id.includes('expmonth') || id.includes('exp-month') || id.includes('exp_month') ||
                            name.includes('expirationmonth') || id.includes('expirationmonth') ||
                            name.includes('ccexpmonth') || id.includes('ccexpmonth') ||
                            name.includes('ppw-expirationdate_month') || id.includes('ppw-expirationdate_month') ||
                            ((name.includes('month') || id.includes('month') || norm.includes('month')) && (norm.includes('card') || norm.includes('exp') || norm.includes('valid')));

      const isYearByAttr = autocomplete.includes('cc-exp-year') ||
                           name.includes('expyear') || name.includes('exp-year') || name.includes('exp_year') ||
                           id.includes('expyear') || id.includes('exp-year') || id.includes('exp_year') ||
                           name.includes('expirationyear') || id.includes('expirationyear') ||
                           name.includes('ccexpyear') || id.includes('ccexpyear') ||
                           name.includes('ppw-expirationdate_year') || id.includes('ppw-expirationdate_year') ||
                           ((name.includes('year') || id.includes('year') || norm.includes('year')) && (norm.includes('card') || norm.includes('exp') || norm.includes('valid')));

      if (isMonthByAttr || (!isYearByAttr && hasStrongMonthOptions && !hasStrongYearOptions)) {
        if (!monthSelect) monthSelect = sel;
      } else if (isYearByAttr || (!isMonthByAttr && hasStrongYearOptions && !hasStrongMonthOptions)) {
        if (!yearSelect) yearSelect = sel;
      } else if (hasCombinedOptions || autocomplete === 'cc-exp' || norm.includes('expiry') || norm.includes('expiration')) {
        if (!combinedSelect) combinedSelect = sel;
      }
    });

    if (monthSelect) {
      const monthCandidates = [
        parsed.month2,
        parsed.month1,
        `${parsed.month2} - ${parsed.monthShort}`,
        `${parsed.month1} - ${parsed.monthShort}`,
        `${parsed.month2} - ${parsed.monthFull}`,
        `${parsed.month1} - ${parsed.monthFull}`,
        `${parsed.month2}/${parsed.monthShort}`,
        `${parsed.monthShort} (${parsed.month2})`,
        `${parsed.month2} (${parsed.monthShort})`,
        parsed.monthShort,
        parsed.monthFull
      ];
      if (setSelectValue(monthSelect, monthCandidates)) filledCount++;
    }

    if (yearSelect) {
      const yearCandidates = [
        parsed.year4,
        parsed.year2,
        `'${parsed.year2}`
      ];
      if (setSelectValue(yearSelect, yearCandidates)) filledCount++;
    }

    if (!monthSelect && !yearSelect && combinedSelect) {
      const combinedCandidates = [
        `${parsed.month2}/${parsed.year2}`,
        `${parsed.month2} / ${parsed.year2}`,
        `${parsed.month2}/${parsed.year4}`,
        `${parsed.month2} / ${parsed.year4}`,
        `${parsed.monthShort} ${parsed.year4}`,
        `${parsed.monthFull} ${parsed.year4}`
      ];
      if (setSelectValue(combinedSelect, combinedCandidates)) filledCount++;
    }

    return filledCount;
  }

  function fillCardDetails(focusedInput, card, currentFieldType) {
    const parsedExpiry = parseCardExpiry(card.expiry);
    const cardNumFormatted = getCardNumberFormattedForInput(focusedInput, card.cardNumber);
    const expiryFormatted = getExpiryFormattedForInput(focusedInput, card.expiry);

    // Fill current focused field first
    if (currentFieldType === 'CARD_NUMBER') setInputValue(focusedInput, cardNumFormatted);
    if (currentFieldType === 'EXPIRY') setInputValue(focusedInput, expiryFormatted);
    if (currentFieldType === 'EXPIRY_MONTH') setInputValue(focusedInput, parsedExpiry ? parsedExpiry.month2 : '');
    if (currentFieldType === 'EXPIRY_YEAR') {
      const yr = parsedExpiry ? (focusedInput.maxLength === 4 ? parsedExpiry.year4 : parsedExpiry.year2) : '';
      setInputValue(focusedInput, yr);
    }
    if (currentFieldType === 'CVV') setInputValue(focusedInput, card.cvv);
    if (currentFieldType === 'CARD_HOLDER') setInputValue(focusedInput, card.cardHolder);

    // Also scan form or page to auto-fill sister fields simultaneously!
    const inputs = getAllPageInputs(focusedInput);
    inputs.forEach(inp => {
      if (inp === focusedInput) return;
      const t = classifyInput(inp);
      if (t === 'CARD_NUMBER' && card.cardNumber) {
        setInputValue(inp, getCardNumberFormattedForInput(inp, card.cardNumber));
      }
      if (t === 'EXPIRY' && card.expiry) {
        setInputValue(inp, getExpiryFormattedForInput(inp, card.expiry));
      }
      if (t === 'EXPIRY_MONTH' && parsedExpiry) {
        setInputValue(inp, parsedExpiry.month2);
      }
      if (t === 'EXPIRY_YEAR' && parsedExpiry) {
        setInputValue(inp, inp.maxLength === 4 ? parsedExpiry.year4 : parsedExpiry.year2);
      }
      if (t === 'CVV' && card.cvv) {
        setInputValue(inp, card.cvv);
      }
      if (t === 'CARD_HOLDER' && card.cardHolder) {
        setInputValue(inp, card.cardHolder);
      }
    });

    // Also auto-fill any <select> dropdowns for Expiry Month & Year!
    const parentContainer = focusedInput ? (focusedInput.closest('form, div[class*="payment"], div[class*="checkout"], div[class*="card"], fieldset') || document) : document;
    fillCardExpirySelects(parentContainer, card.expiry);
  }

  function fillBankAccountDetails(focusedInput, account, bank, currentFieldType) {
    if (currentFieldType === 'ACCOUNT_NUMBER') setInputValue(focusedInput, account.accountNumber);
    if (currentFieldType === 'IFSC') setInputValue(focusedInput, account.ifscCode);

    // Scan sister fields
    const inputs = getAllPageInputs(focusedInput);
    inputs.forEach(inp => {
      if (inp === focusedInput) return;
      const t = classifyInput(inp);
      if (t === 'ACCOUNT_NUMBER' && account.accountNumber) setInputValue(inp, account.accountNumber);
      if (t === 'IFSC' && account.ifscCode) setInputValue(inp, account.ifscCode);
    });
  }

  function fillCredentials(focusedInput, bank, currentFieldType) {
    if (currentFieldType === 'USER_ID') setInputValue(focusedInput, bank.userId);
    if (currentFieldType === 'PASSWORD') setInputValue(focusedInput, bank.loginPassword || bank.profilePassword || bank.mpin);

    const inputs = getAllPageInputs(focusedInput);
    inputs.forEach(inp => {
      if (inp === focusedInput) return;
      const t = classifyInput(inp);
      if (t === 'USER_ID' && bank.userId) setInputValue(inp, bank.userId);
      if (t === 'PASSWORD' && (bank.loginPassword || bank.profilePassword)) {
        setInputValue(inp, bank.loginPassword || bank.profilePassword);
      }
    });
  }

  function fillPasswordCredentials(focusedInput, pwd, currentFieldType) {
    if (currentFieldType === 'USER_ID') setInputValue(focusedInput, pwd.username);
    if (currentFieldType === 'PASSWORD') setInputValue(focusedInput, pwd.password);

    // Auto-fill sister input in form or page
    const inputs = getAllPageInputs(focusedInput);
    inputs.forEach(inp => {
      if (inp === focusedInput) return;
      const t = classifyInput(inp);
      if (t === 'USER_ID' && pwd.username) setInputValue(inp, pwd.username);
      if (t === 'PASSWORD' && pwd.password) setInputValue(inp, pwd.password);
    });
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>'"]/g, tag => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      "'": '&#39;',
      '"': '&quot;'
    }[tag] || tag));
  }

  // ── Automatic "Save Password" Prompt ──
  let activePromptCard = null;

  function removeSavePrompt() {
    if (activePromptCard) {
      activePromptCard.remove();
      activePromptCard = null;
    }
  }

  function showSavePasswordPrompt(domain, username, password) {
    removeSavePrompt();

    const card = document.createElement('div');
    card.className = 'cv-save-prompt-card';
    card.innerHTML = `
      <div class="cv-prompt-header">
        <div class="cv-prompt-title">
          <span>🛡️</span>
          <span>TetherPass</span>
        </div>
        <button class="cv-prompt-close" title="Dismiss">✕</button>
      </div>
      <div class="cv-prompt-body">
        <div>Save credentials for <strong>${escapeHtml(domain)}</strong> to your encrypted vault?</div>
        <div class="cv-prompt-user-badge">
          <span>👤</span>
          <span>${escapeHtml(username || 'Account')}</span>
        </div>
      </div>
      <div class="cv-prompt-actions">
        <button class="cv-btn-dismiss">Ignore</button>
        <button class="cv-btn-save">Save to Vault</button>
      </div>
    `;

    card.querySelector('.cv-prompt-close').addEventListener('click', removeSavePrompt);
    card.querySelector('.cv-btn-dismiss').addEventListener('click', removeSavePrompt);

    card.querySelector('.cv-btn-save').addEventListener('click', () => {
      chrome.runtime.sendMessage({
        action: 'SAVE_NEW_PASSWORD',
        payload: {
          website: domain,
          username: username || '',
          password: password,
          nickname: domain
        }
      }, (res) => {
        if (res && res.success) {
          card.querySelector('.cv-prompt-body').innerHTML = `
            <div style="color: #10B981; font-weight: 700;">✅ Saved to TetherPass!</div>
          `;
          setTimeout(removeSavePrompt, 2000);
        } else {
          removeSavePrompt();
        }
      });
    });

    document.body.appendChild(card);
    activePromptCard = card;

    setTimeout(() => {
      if (activePromptCard === card) removeSavePrompt();
    }, 15000);
  }

  // ── Listener for Direct Autofill from Extension Popup ──
  if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message && message.action === 'VAULT_STATUS_CHANGED') {
        const unlocked = !!(message.isAuthorized && message.isUnlocked);
        if (unlocked) {
          isVaultUnlocked = true;
        } else {
          purgeAllTetherPassElements();
        }
      }

      if (!isVaultUnlocked) {
        if (sendResponse) sendResponse({ success: false, error: 'Vault is locked' });
        return;
      }

      if (message && message.action === 'FILL_CARD_NOW' && message.card) {
        const count = fillAllCardInputsOnPage(message.card);
        showFillToast(count > 0 ? 'Card details autofilled!' : 'No payment inputs found on page', count > 0);
        sendResponse({ success: true, count });
      }

      if (message && message.action === 'FILL_BANK_NOW' && message.bank) {
        const count = fillAllBankInputsOnPage(message.bank);
        showFillToast(count > 0 ? `${message.bank.bankName || 'Bank'} credentials autofilled!` : 'No bank inputs found on page', count > 0);
        sendResponse({ success: true, count });
      }

      if (message && message.action === 'FILL_PASSWORD_NOW' && message.password) {
        const count = fillAllPasswordInputsOnPage(message.password);
        showFillToast(count > 0 ? `${message.password.nickname || 'Login'} details autofilled!` : 'No login inputs found on page', count > 0);
        sendResponse({ success: true, count });
      }
    });
  }

  function fillAllBankInputsOnPage(bank) {
    const inputs = Array.from(document.querySelectorAll('input')).filter(inp => {
      return inp.type !== 'hidden' && inp.type !== 'submit' && inp.type !== 'button';
    });
    let filledCount = 0;
    const acc = (bank.accounts && bank.accounts.length > 0) ? bank.accounts[0] : null;

    inputs.forEach(inp => {
      const type = classifyInput(inp);
      if (type === 'USER_ID' && bank.userId) {
        setInputValue(inp, bank.userId);
        filledCount++;
      } else if (type === 'PASSWORD' && (bank.loginPassword || bank.profilePassword || bank.mpin)) {
        setInputValue(inp, bank.loginPassword || bank.profilePassword || bank.mpin);
        filledCount++;
      } else if (type === 'ACCOUNT_NUMBER' && acc && acc.accountNumber) {
        setInputValue(inp, acc.accountNumber);
        filledCount++;
      } else if (type === 'IFSC' && acc && acc.ifscCode) {
        setInputValue(inp, acc.ifscCode);
        filledCount++;
      }
    });
    return filledCount;
  }

  function fillAllPasswordInputsOnPage(pwd) {
    const inputs = Array.from(document.querySelectorAll('input')).filter(inp => {
      return inp.type !== 'hidden' && inp.type !== 'submit' && inp.type !== 'button';
    });
    let filledCount = 0;
    inputs.forEach(inp => {
      const type = classifyInput(inp);
      if (type === 'USER_ID' && (pwd.username || pwd.userId)) {
        setInputValue(inp, pwd.username || pwd.userId);
        filledCount++;
      } else if (type === 'PASSWORD' && (pwd.password || pwd.loginPassword)) {
        setInputValue(inp, pwd.password || pwd.loginPassword);
        filledCount++;
      }
    });
    return filledCount;
  }

  function fillAllCardInputsOnPage(card) {
    const inputs = Array.from(document.querySelectorAll('input')).filter(inp => {
      return inp.type !== 'hidden' && inp.type !== 'submit' && inp.type !== 'button';
    });

    const parsedExpiry = parseCardExpiry(card.expiry);
    let filledCount = 0;
    inputs.forEach(inp => {
      const type = classifyInput(inp);
      if (type === 'CARD_NUMBER' && card.cardNumber) {
        const formatted = getCardNumberFormattedForInput(inp, card.cardNumber);
        setInputValue(inp, formatted);
        filledCount++;
      } else if (type === 'EXPIRY' && card.expiry) {
        const formatted = getExpiryFormattedForInput(inp, card.expiry);
        setInputValue(inp, formatted);
        filledCount++;
      } else if (type === 'EXPIRY_MONTH' && parsedExpiry) {
        setInputValue(inp, parsedExpiry.month2);
        filledCount++;
      } else if (type === 'EXPIRY_YEAR' && parsedExpiry) {
        setInputValue(inp, inp.maxLength === 4 ? parsedExpiry.year4 : parsedExpiry.year2);
        filledCount++;
      } else if (type === 'CVV' && card.cvv) {
        setInputValue(inp, card.cvv);
        filledCount++;
      } else if (type === 'CARD_HOLDER' && card.cardHolder) {
        setInputValue(inp, card.cardHolder);
        filledCount++;
      }
    });

    // Auto-fill <select> dropdowns across page / forms
    const selectCount = fillCardExpirySelects(document, card.expiry);
    filledCount += selectCount;

    return filledCount;
  }

  function showFillToast(text, isSuccess = true) {
    // If this frame found 0 inputs, but it is top frame with iframes,
    // suppress negative toast since an iframe contains the payment gateway!
    if (!isSuccess && window.self === window.top && document.querySelectorAll('iframe').length > 0) {
      return;
    }

    const toast = document.createElement('div');
    toast.style.cssText = `
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      background: #0F172A;
      color: #FFFFFF;
      padding: 10px 20px;
      border-radius: 24px;
      font-size: 13px;
      font-weight: 700;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
      z-index: 2147483647;
      display: flex;
      align-items: center;
      gap: 8px;
      border: 1px solid rgba(255, 111, 0, 0.5);
      pointer-events: none;
      transition: opacity 0.3s ease;
    `;
    toast.innerHTML = `<span>🛡️</span><span>${escapeHtml(text)}</span>`;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }, 2200);
  }

  // Intercept form submissions to offer saving new credentials ONLY WHEN UNLOCKED
  document.addEventListener('submit', (e) => {
    if (!isVaultUnlocked) return;
    try {
      const form = e.target;
      if (!form || !form.querySelector) return;
      const pwdInput = form.querySelector('input[type="password"]');
      if (!pwdInput || !pwdInput.value || pwdInput.value.length < 3) return;

      // Find username / email
      let userInput = form.querySelector('input[type="email"], input[name*="user" i], input[name*="email" i], input[autocomplete*="username" i], input[autocomplete*="email" i]');
      if (!userInput) {
        const inputs = Array.from(form.querySelectorAll('input:not([type="hidden"]):not([type="submit"])'));
        const idx = inputs.indexOf(pwdInput);
        if (idx > 0) userInput = inputs[idx - 1];
      }

      const domain = window.location.hostname.replace(/^www\./, '');
      const userVal = userInput ? userInput.value.trim() : '';
      const pwdVal = pwdInput.value;

      showSavePasswordPrompt(domain, userVal, pwdVal);
    } catch (_) {}
  }, true);
})();
