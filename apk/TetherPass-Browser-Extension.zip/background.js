/**
 * TetherPass Extension Service Worker (Manifest V3)
 * Manages encrypted session cache of vault items and enforces Mobile Authorization.
 */

importScripts('crypto_utils.js', 'drive_client.js');

const driveClient = new DriveClient();

// Automatically restore OAuth token on startup without popping up any interactive window
if (typeof chrome !== 'undefined' && chrome.storage?.local) {
  chrome.storage.local.get('googleOAuthToken', (data) => {
    if (data?.googleOAuthToken) {
      driveClient.setToken(data.googleOAuthToken);
    }
  });
}

// Restrict session storage access strictly to trusted extension contexts (background & popup)
if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.session) {
  if (chrome.storage.session.setAccessLevel) {
    chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' }).catch(() => {});
  }
}

// Security Enforcement: Proactively purge any legacy decrypted or session records from disk-backed local storage
if (typeof chrome !== 'undefined' && chrome.storage?.local) {
  chrome.storage.local.remove(['tetherpass_session', 'cachedBackupPayload'], () => {
    console.log('[TetherPass Security] Disk-backed local storage sanitized of sensitive records.');
  });
}

// In-memory cache (restored from chrome.storage.session across service worker restarts)
let memoryVault = {
  isAuthorized: false,
  isUnlocked: false,
  items: [],
  lastSyncedAt: null,
  authExpiresAt: null,
  masterPassword: null,
  authMode: null,
  sessionStartTime: null,
  activeRequestId: null,
  sessionId: null,
};

// Universal normalizer for raw decrypted vault items into structured suggestions
function organizeVaultItems(rawItems) {
  const cards = [];
  const bankAccounts = [];
  const passwords = [];

  if (!Array.isArray(rawItems)) return { cards, bankAccounts, passwords };

  for (const item of rawItems) {
    const type = (item.type || '').toLowerCase();
    const isPassword = type === 'password';
    const rawCardNumber = String(item.card_number || item.cardNumber || item.number || item.cardNo || item.card_no || '').replace(/\s+/g, '');
    const isCard = !isPassword && (type === 'card' || (!type.includes('bank') && (rawCardNumber.length >= 12 || (item.card_network || item.cardNetwork))));

    if (isPassword) {
      const totpKey = item.totp_secret || item.totpSecret || '';
      passwords.push({
        id: item.id || String(Math.random()),
        nickname: item.nickname || item.bank_name || 'Website Password',
        website: item.website || '',
        username: item.user_id || item.userId || item.username || '',
        password: item.login_password || item.loginPassword || item.password || '',
        totpSecret: totpKey,
        notes: item.notes || ''
      });
    } else if (isCard) {
      cards.push({
        id: item.id || String(Math.random()),
        nickname: item.nickname || item.name || item.card_holder || item.cardHolder || 'Card',
        bankName: item.bank_name || item.bankName || 'Card',
        cardNumber: rawCardNumber,
        cardHolder: item.card_holder || item.cardHolder || '',
        expiry: item.expiry || item.card_expiry || item.cardExpiry || '',
        cvv: item.cvv || item.card_cvv || item.cardCvv || '',
        cardNetwork: item.card_network || item.cardNetwork || 'Visa',
        isCredit: (item.card_type || item.cardType || '').toLowerCase().includes('credit') || !!item.isCredit,
        isDebit: (item.card_type || item.cardType || '').toLowerCase().includes('debit') || !!item.isDebit
      });
    } else {
      let rawAccounts = [];
      if (item.accounts) {
        try {
          rawAccounts = typeof item.accounts === 'string' ? JSON.parse(item.accounts) : item.accounts;
        } catch (_) {}
      }

      const normalizedAccounts = [];
      if (Array.isArray(rawAccounts) && rawAccounts.length > 0) {
        for (const a of rawAccounts) {
          const accNum = String(a.account_number || a.accountNumber || a.accountNo || a.acc_num || a.acc_no || a.accNo || '').trim();
          const ifsc = String(a.ifsc_code || a.ifscCode || a.ifsc || '').trim().toUpperCase();
          if (accNum || ifsc) {
            normalizedAccounts.push({
              accountNumber: accNum,
              ifscCode: ifsc,
              label: a.label || ''
            });
          }
        }
      }

      const primaryAcc = String(item.account_number || item.accountNumber || item.accountNo || item.acc_num || item.acc_no || item.accNo || '').trim();
      const primaryIfsc = String(item.ifsc_code || item.ifscCode || item.ifsc || '').trim().toUpperCase();
      if ((primaryAcc || primaryIfsc) && !normalizedAccounts.some(a => a.accountNumber === primaryAcc && a.accountNumber !== '')) {
        normalizedAccounts.unshift({
          accountNumber: primaryAcc,
          ifscCode: primaryIfsc,
          label: 'Primary'
        });
      }

      bankAccounts.push({
        id: item.id || String(Math.random()),
        bankName: item.bank_name || item.bankName || item.nickname || 'Bank',
        nickname: item.nickname || '',
        website: item.website || item.url || '',
        accounts: normalizedAccounts,
        userId: item.user_id || item.userId || item.username || '',
        cifNumber: item.cif_number || item.cifNumber || item.cif || '',
        loginPassword: item.login_password || item.loginPassword || item.password || '',
        profilePassword: item.profile_password || item.profilePassword || '',
        mpin: item.mpin || '',
        notes: item.notes || ''
      });
    }
  }

  return { cards, bankAccounts, passwords };
}

// ── RAM-Only Session Storage (Kept exclusively in volatile memory; NEVER written to disk) ──
async function persistSession() {
  const suggestions = organizeVaultItems(memoryVault.items);
  // Master password and decrypted items must NEVER touch persistent disk storage.
  // We keep session data exclusively in chrome.storage.session (RAM only).
  const sessionData = {
    isAuthorized: memoryVault.isAuthorized,
    isUnlocked: memoryVault.isUnlocked,
    items: memoryVault.items,
    suggestions: suggestions,
    lastSyncedAt: memoryVault.lastSyncedAt,
    authExpiresAt: memoryVault.authExpiresAt,
    authMode: memoryVault.authMode,
    sessionStartTime: memoryVault.sessionStartTime,
    activeRequestId: memoryVault.activeRequestId,
    sessionId: memoryVault.sessionId,
  };

  try {
    if (typeof chrome !== 'undefined' && chrome.storage?.session) {
      await chrome.storage.session.set({ tetherpass_session: sessionData });
    }
  } catch (err) {
    console.warn('[TetherPass] Session storage write error:', err);
  }

  // Active Anti-Disk-Leak Safeguard:
  // Ensure that under no condition does chrome.storage.local (LevelDB disk cache)
  // hold any session records or decrypted payloads.
  try {
    if (typeof chrome !== 'undefined' && chrome.storage?.local) {
      await chrome.storage.local.remove(['tetherpass_session', 'cachedBackupPayload']);
    }
  } catch (_) {}
}

async function restoreSessionIfNeeded() {
  const now = Date.now();

  // If already unlocked in RAM, verify expiry timestamp (guaranteed 30 minutes)
  if (memoryVault.isAuthorized && memoryVault.isUnlocked) {
    if (memoryVault.authExpiresAt && now > memoryVault.authExpiresAt) {
      await lockVault('Authorization session expired.');
      return false;
    }
    return true;
  }

  // Restore session strictly from chrome.storage.session (volatile RAM only)
  try {
    let sess = null;
    if (typeof chrome !== 'undefined' && chrome.storage?.session) {
      const data = await chrome.storage.session.get('tetherpass_session');
      sess = data?.tetherpass_session;
    }

    if (sess && sess.isAuthorized && sess.isUnlocked) {
      if (sess.authExpiresAt && now > sess.authExpiresAt) {
        await lockVault('Authorization session expired.');
        return false;
      }

      memoryVault = {
        isAuthorized: true,
        isUnlocked: true,
        items: sess.items || [],
        lastSyncedAt: sess.lastSyncedAt || now,
        authExpiresAt: sess.authExpiresAt,
        masterPassword: memoryVault.masterPassword || null,
        authMode: sess.authMode || null,
        sessionStartTime: sess.sessionStartTime || now,
        activeRequestId: sess.activeRequestId || null,
        sessionId: sess.sessionId || null,
      };
      return true;
    }
  } catch (err) {
    console.warn('[TetherPass] Session restore notice:', err);
  }

  return false;
}

async function clearPersistedSession() {
  try {
    if (typeof chrome !== 'undefined' && chrome.storage?.session) {
      await chrome.storage.session.remove('tetherpass_session');
    }
  } catch (_) {}
  try {
    if (typeof chrome !== 'undefined' && chrome.storage?.local) {
      await chrome.storage.local.remove(['tetherpass_session', 'cachedBackupPayload']);
    }
  } catch (_) {}
}

// Auto-lock timer / Periodic validation of mobile auth status
async function verifyMobileAuth() {
  await restoreSessionIfNeeded();
  if (!memoryVault.isAuthorized || !memoryVault.isUnlocked) return;

  if (!driveClient.token) {
    const stored = await chrome.storage.local.get('googleOAuthToken');
    if (stored?.googleOAuthToken) {
      driveClient.setToken(stored.googleOAuthToken);
    } else {
      return; // Do not check Drive without token; strictly avoid triggering interactive OAuth
    }
  }

  // Poll Google Drive for intentional remote revocation or termination from mobile
  try {
    const isRevoked = await driveClient.isAuthorizationRevoked(
      memoryVault.authMode,
      memoryVault.sessionStartTime,
      memoryVault.sessionId
    );
    if (isRevoked) {
      await lockVault('Session terminated from TetherPass mobile application.');
      return;
    }

    // Check if session was extended remotely from mobile
    const remoteExpiresAt = await driveClient.getRemoteSessionExpiresAt(
      memoryVault.sessionId,
      memoryVault.authMode
    );
    if (remoteExpiresAt && remoteExpiresAt > (memoryVault.authExpiresAt || 0)) {
      memoryVault.authExpiresAt = remoteExpiresAt;
      await persistSession();
      notifyAllTabsStatusChange();
    }
  } catch (_) {
    // Soft error, rely on local timeout
  }

  // Enforce desktop session expiration timestamp (full duration or extended)
  if (memoryVault.authExpiresAt && Date.now() > memoryVault.authExpiresAt) {
    await lockVault('Mobile authorization session expired.');
    return;
  }
}

async function lockVault(reason = 'Vault locked') {
  let sessionIdToLock = memoryVault.sessionId || memoryVault.activeRequestId;

  if (!sessionIdToLock) {
    try {
      const sessData = await chrome.storage.session.get('tetherpass_session');
      sessionIdToLock = sessData?.tetherpass_session?.sessionId || sessData?.tetherpass_session?.activeRequestId;
    } catch (_) {}
  }

  // Clear in-memory state immediately for zero-latency lock
  memoryVault.isAuthorized = false;
  memoryVault.isUnlocked = false;
  memoryVault.items = [];
  memoryVault.masterPassword = null;
  memoryVault.authExpiresAt = null;
  memoryVault.authMode = null;
  memoryVault.sessionStartTime = null;
  memoryVault.activeRequestId = null;
  memoryVault.sessionId = null;

  await clearPersistedSession();
  console.log('[TetherPass]', reason);

  notifyAllTabsStatusChange();

  // Internal runtime message to instantly notify popup if open
  chrome.runtime.sendMessage({
    action: 'VAULT_STATUS_CHANGED',
    isAuthorized: false,
    isUnlocked: false,
    reason
  }).catch(() => {});

  // Mark session as LOCKED in Google Drive so mobile updates and subsequent requests don't race
  try {
    if (!driveClient.token) {
      const stored = await chrome.storage.local.get('googleOAuthToken');
      if (stored?.googleOAuthToken) {
        driveClient.setToken(stored.googleOAuthToken);
      }
    }
    if (driveClient.token) {
      await driveClient.markSessionLocked(sessionIdToLock);
      console.log('[TetherPass] Session marked LOCKED on Drive:', sessionIdToLock);
    } else {
      console.warn('[TetherPass] No token available — cannot mark session LOCKED on Drive');
    }
  } catch (e) {
    console.warn('[TetherPass] Could not mark session locked on Drive:', e.message);
  }
}

function notifyAllTabsStatusChange() {
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, {
          action: 'VAULT_STATUS_CHANGED',
          isAuthorized: memoryVault.isAuthorized && memoryVault.isUnlocked
        }).catch(() => {});
      }
    }
  });
}

// Listen for messages from Content Script and Popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const { action, payload } = message;

  (async () => {
    // Always restore session state first before processing any message
    await restoreSessionIfNeeded();

    if (action === 'GET_STATUS') {
      const suggestions = (memoryVault.isAuthorized && memoryVault.isUnlocked)
        ? organizeVaultItems(memoryVault.items)
        : { cards: [], bankAccounts: [], passwords: [] };

      sendResponse({
        isAuthorized: memoryVault.isAuthorized,
        isUnlocked: memoryVault.isUnlocked,
        itemCount: memoryVault.items.length,
        lastSyncedAt: memoryVault.lastSyncedAt,
        authExpiresAt: memoryVault.authExpiresAt,
        authMode: memoryVault.authMode,
        suggestions: suggestions,
      });
      return;
    }

    if (action === 'LOCK_VAULT') {
      if (payload?.token) driveClient.setToken(payload.token);
      await lockVault('User requested desktop lock');
      sendResponse({ success: true });
      return;
    }

    if (action === 'GET_REGISTERED_DEVICES') {
      if (payload?.token) driveClient.setToken(payload.token);
      try {
        const devices = await driveClient.fetchRegisteredDevices();
        sendResponse({ success: true, devices });
      } catch (err) {
        sendResponse({ success: false, devices: [], error: err.message });
      }
      return;
    }

    if (action === 'REMOVE_REGISTERED_DEVICE') {
      if (payload?.token) driveClient.setToken(payload.token);
      try {
        const devices = await driveClient.removeRegisteredDevice(payload.deviceId);
        sendResponse({ success: true, devices });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return;
    }

    if (action === 'RENAME_REGISTERED_DEVICE') {
      if (payload?.token) driveClient.setToken(payload.token);
      try {
        const devices = await driveClient.renameRegisteredDevice(payload.deviceId, payload.newName);
        sendResponse({ success: true, devices });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return;
    }

    if (action === 'START_MOBILE_APPROVAL_REQUEST') {
      try {
        const res = await handleStartMobileApprovalRequest(payload);
        sendResponse(res);
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return;
    }

    if (action === 'POLL_MOBILE_APPROVAL') {
      try {
        const res = await handlePollMobileApproval(payload);
        sendResponse(res);
      } catch (err) {
        sendResponse({ status: 'ERROR', error: err.message });
      }
      return;
    }

    if (action === 'CANCEL_MOBILE_APPROVAL_REQUEST' || action === 'EXPIRE_MOBILE_APPROVAL_REQUEST') {
      if (payload?.token) driveClient.setToken(payload.token);
      try {
        if (payload?.requestId) {
          await driveClient.expireAccessRequest(payload.requestId);
        }
        sendResponse({ success: true });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return;
    }

    if (action === 'AUDIO_HANDSHAKE_VERIFIED') {
      try {
        const res = await handleAudioHandshakeVerified(payload);
        sendResponse(res);
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return;
    }

    if (action === 'GET_AUTOFILL_SUGGESTIONS') {
      try {
        const res = await handleGetAutofillSuggestions(payload);
        sendResponse(res);
      } catch (_) {
        sendResponse({ authorized: false, items: [] });
      }
      return;
    }

    if (action === 'SAVE_NEW_PASSWORD') {
      try {
        const res = await handleSaveNewPassword(payload);
        sendResponse(res);
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return;
    }

    if (action === 'CHECK_BREACH') {
      try {
        const res = await checkPasswordBreached(payload.password);
        sendResponse(res);
      } catch (err) {
        sendResponse({ isPwned: false, error: err.message });
      }
      return;
    }

    if (action === 'EXTEND_SESSION') {
      try {
        if (!memoryVault.isAuthorized && !memoryVault.isUnlocked) {
          sendResponse({ success: false, error: 'Vault is not unlocked' });
          return;
        }
        const additionalMinutes = payload?.minutes || 15;
        const addMs = additionalMinutes * 60 * 1000;
        const base = (memoryVault.authExpiresAt && memoryVault.authExpiresAt > Date.now())
          ? memoryVault.authExpiresAt
          : Date.now();
        memoryVault.authExpiresAt = base + addMs;
        await persistSession();

        // Also extend remotely on Google Drive so mobile app receives it immediately!
        if (payload?.token && memoryVault.sessionId) {
          try {
            driveClient.setToken(payload.token);
            await driveClient.extendRemoteSession(memoryVault.sessionId, memoryVault.authExpiresAt, memoryVault.authMode);
          } catch (_) {}
        }

        notifyAllTabsStatusChange();
        chrome.runtime.sendMessage({
          action: 'VAULT_STATUS_CHANGED',
          isAuthorized: true,
          isUnlocked: true,
          authExpiresAt: memoryVault.authExpiresAt
        }).catch(() => {});

        sendResponse({ success: true, authExpiresAt: memoryVault.authExpiresAt });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
      return;
    }
  })();

  return true; // Asynchronous sendResponse channel
});

let lastRequestedDeviceName = null;

async function getDesktopDeviceName(fallback = 'Windows PC (Chrome)') {
  if (lastRequestedDeviceName) return lastRequestedDeviceName;
  try {
    if (typeof chrome !== 'undefined' && chrome.storage?.local) {
      const stored = await chrome.storage.local.get(['customDesktopName', 'desktopDeviceTag']);
      if (stored.customDesktopName) return stored.customDesktopName;
      if (stored.desktopDeviceTag) return `Windows PC (Chrome • ${stored.desktopDeviceTag})`;
    }
  } catch (_) {}
  return fallback;
}

async function handleStartMobileApprovalRequest({ token, deviceName, targetDeviceId, authMode }) {
  if (token) driveClient.setToken(token);
  if (deviceName) lastRequestedDeviceName = deviceName;
  const req = await driveClient.sendAccessRequestToMobile(
    deviceName || 'Windows PC (TetherPass Extension)',
    targetDeviceId || 'ALL',
    authMode || 'PUSH'
  );
  return {
    success: true,
    requestId: req.requestId,
    expiresAt: req.expiresAt
  };
}

async function handlePollMobileApproval({ token, requestId, masterPassword }) {
  if (token) driveClient.setToken(token);

  const check = await driveClient.checkAccessRequestStatus(requestId);
  if (check.status === 'APPROVED') {
    let effectivePassword = masterPassword;
    if (!effectivePassword && check.request_sealed_key) {
      try {
        effectivePassword = await decryptSealedMasterPassword(check.request_sealed_key, requestId);
      } catch (e) {
        console.warn('[CardVault] Could not decrypt request_sealed_key:', e.message);
      }
    }

    if (!effectivePassword) {
      return {
        status: 'APPROVED',
        success: false,
        error: 'PASSWORD_REQUIRED',
        message: 'Master Password required to decrypt vault. Please re-enter your password or re-authorize.'
      };
    }

    // Mobile approved with biometrics! Download backup from Drive
    const backupPayload = await driveClient.fetchEncryptedVaultBackup();
    const decryptedItems = await decryptCardVaultBackup(backupPayload, effectivePassword);

    // Save in RAM and session storage with a synchronized 30-minute desktop session
    const desktopSessionDurationMs = 30 * 60 * 1000;
    const sessionId = requestId || ('sess_' + Date.now());
    memoryVault.isAuthorized = true;
    memoryVault.isUnlocked = true;
    memoryVault.items = decryptedItems;
    memoryVault.lastSyncedAt = Date.now();

    // NTP clock synchronization: eliminate any seconds difference between Phone clock and PC clock
    const nowDesktop = Date.now();
    let desktopAuthExpiresAt = nowDesktop + desktopSessionDurationMs;
    if (check.expiresAt && check.approvedAt) {
      const reqAt = check.requestedAt || (nowDesktop - 1500);
      const halfRoundtrip = Math.max(0, Math.floor((nowDesktop - reqAt) / 2));
      const clockOffset = check.approvedAt - (reqAt + halfRoundtrip);
      desktopAuthExpiresAt = check.expiresAt - clockOffset;
    }
    memoryVault.authExpiresAt = desktopAuthExpiresAt;
    memoryVault.masterPassword = effectivePassword;
    memoryVault.activeRequestId = requestId;
    memoryVault.sessionId = sessionId;
    memoryVault.authMode = 'PUSH';
    memoryVault.sessionStartTime = nowDesktop;

    await persistSession();

    notifyAllTabsStatusChange();

    return {
      status: 'APPROVED',
      success: true,
      itemCount: decryptedItems.length,
      expiresAt: memoryVault.authExpiresAt,
      isAuthorized: true,
      isUnlocked: true,
      suggestions: organizeVaultItems(decryptedItems)
    };
  }

  return check;
}

async function handleAudioHandshakeVerified(payload) {
  const { token, oauthToken } = payload || {};
  if (oauthToken) driveClient.setToken(oauthToken);

  const desktopSessionDurationMs = 30 * 60 * 1000;
  const now = Date.now();

  memoryVault.isAuthorized = true;
  memoryVault.isUnlocked = true;
  memoryVault.authMode = 'AUDIO_CHIRP';
  memoryVault.sessionStartTime = now;
  memoryVault.authExpiresAt = now + desktopSessionDurationMs;
  memoryVault.sessionId = 'audio_' + now;
  memoryVault.activeRequestId = 'audio_' + (token || 'handshake');
  memoryVault.lastSyncedAt = now;

  // If memory has items, keep them. Otherwise attempt to fetch from Drive if authorized
  if ((!memoryVault.items || memoryVault.items.length === 0) && memoryVault.masterPassword) {
    try {
      const backupPayload = await driveClient.fetchEncryptedVaultBackup();
      if (backupPayload) {
        memoryVault.items = await decryptCardVaultBackup(backupPayload, memoryVault.masterPassword);
      }
    } catch (e) {
      console.warn('[AudioHandshake] Drive backup fetch error:', e.message);
    }
  }

  await persistSession();
  notifyAllTabsStatusChange();

  return {
    status: 'APPROVED',
    success: true,
    itemCount: (memoryVault.items || []).length,
    expiresAt: memoryVault.authExpiresAt,
    isAuthorized: true,
    isUnlocked: true,
    suggestions: organizeVaultItems(memoryVault.items || [])
  };
}


function extractDomain(urlOrHost) {
  if (!urlOrHost) return '';
  let str = urlOrHost.trim().toLowerCase();
  str = str.replace(/^[a-zA-Z]+:\/\//, '');
  str = str.split('/')[0].split('?')[0].split('#')[0];
  str = str.split(':')[0];
  return str.replace(/^www\./, '');
}

const MULTI_TLDS = ['co', 'com', 'org', 'net', 'edu', 'gov', 'ac', 'bank', 'mil', 'nic', 'res', 'gen'];
const STOP_WORDS = ['bank', 'banking', 'netbanking', 'login', 'portal', 'app', 'account', 'card', 'pass', 'password', 'online', 'store', 'auth', 'web', 'mobile', 'secure', 'retail'];

function extractBaseBrand(domain) {
  if (!domain) return '';
  const clean = extractDomain(domain);
  const parts = clean.split('.');
  if (parts.length <= 1) return parts[0];
  if (parts.length >= 3 && MULTI_TLDS.includes(parts[parts.length - 2])) {
    return parts[parts.length - 3];
  }
  return parts[parts.length - 2];
}

const BANK_DOMAIN_ALIASES = {
  federal: ['federalbank.co.in', 'fednetbank.com', 'federalbank.com', 'fednet', 'federal', 'federal.bank.in'],
  hdfc: ['hdfcbank.com', 'hdfcbank.net', 'hdfc.com', 'hdfc', 'hdfc.bank.in'],
  sbi: ['onlinesbi.sbi', 'onlinesbi.com', 'sbi.co.in', 'statebankofindia.com', 'sbi', 'sbi.bank.in'],
  rbl: ['rblbank.com', 'rblbank.in', 'rbl', 'rbl.bank.in'],
  icici: ['icicibank.com', 'icici.com', 'icici', 'icici.bank.in'],
  axis: ['axisbank.com', 'axisbank.co.in', 'axis', 'axis.bank.in'],
  kotak: ['kotak.com', 'kotakbank.com', 'kotak', 'kotak.bank.in'],
  pnb: ['pnbindia.in', 'netpnb.com', 'pnb', 'pnb.bank.in'],
  bob: ['bankofbaroda.in', 'bobibanking.com', 'bankofbaroda.com', 'bob', 'bob.bank.in'],
  canara: ['canarabank.com', 'canarabank.in', 'canara', 'canarabank.bank.in'],
  idbi: ['idbibank.in', 'idbibank.com', 'idbi', 'idbi.bank.in'],
  indusind: ['indusind.com', 'indusindbank.com', 'indusind', 'indusind.bank.in'],
  yes: ['yesbank.in', 'yesbank.com', 'yes', 'yesbank.bank.in'],
  union: ['unionbankofindia.co.in', 'unionbankonline.co.in', 'union', 'unionbank.bank.in'],
  dbs: ['dbs.com', 'dbs.com.sg', 'dbs'],
  iob: ['iob.in', 'iobnet.co.in', 'iob', 'iob.bank.in'],
  sib: ['southindianbank.com', 'sib.co.in', 'sib', 'southindianbank.bank.in'],
  standardchartered: ['sc.com', 'standardchartered.co.in', 'standardchartered'],
  citi: ['citibank.co.in', 'citibank.com', 'citi']
};

function doesDomainMatch(itemWebsite, pageHost, itemNickname = '') {
  if (!pageHost) return false;
  const pageDom = extractDomain(pageHost);
  const pageBrand = extractBaseBrand(pageDom);

  // 1. Direct website URL / domain match
  if (itemWebsite && itemWebsite.trim()) {
    const itemDom = extractDomain(itemWebsite);
    const itemBrand = extractBaseBrand(itemDom);

    if (itemDom && pageDom) {
      if (itemDom === pageDom) return true;
      if (pageDom.endsWith('.' + itemDom) || itemDom.endsWith('.' + pageDom)) return true;
      if (itemBrand && pageBrand && itemBrand === pageBrand && itemBrand.length >= 3 && !STOP_WORDS.includes(itemBrand)) {
        return true;
      }
    }

    const rawClean = itemWebsite.trim().toLowerCase().replace(/^[a-zA-Z]+:\/\//, '').replace(/^www\./, '');
    if (rawClean.length >= 3) {
      if (pageDom.includes(rawClean) || rawClean.includes(pageDom)) return true;
      if (pageBrand && !STOP_WORDS.includes(pageBrand) && (pageBrand === rawClean || pageBrand.includes(rawClean) || rawClean.includes(pageBrand))) {
        return true;
      }
    }
  }

  // 2. Tokenized Brand Matching (filters out generic words like 'bank', 'banking', 'mobile', etc.)
  if (itemNickname && itemNickname.trim()) {
    const nick = itemNickname.trim().toLowerCase();
    const itemTokens = nick.split(/[^a-z0-9]+/).filter(t => t.length >= 3 && !STOP_WORDS.includes(t));
    const pageTokens = pageDom.split(/[^a-z0-9]+/).filter(t => t.length >= 3 && !STOP_WORDS.includes(t));

    // Direct distinctive token intersection
    for (const t of itemTokens) {
      if (pageTokens.includes(t) || t === pageBrand) return true;
      if (pageBrand && pageBrand.length >= 3 && !STOP_WORDS.includes(pageBrand)) {
        if (pageBrand.startsWith(t) || t.startsWith(pageBrand)) return true;
      }
    }

    // 3. Known Bank Domain Aliases
    for (const [bankKey, aliases] of Object.entries(BANK_DOMAIN_ALIASES)) {
      const bankMatched = itemTokens.includes(bankKey) || nick.includes(bankKey) || (itemWebsite && itemWebsite.toLowerCase().includes(bankKey));
      if (bankMatched) {
        if (aliases.some(a => pageDom.includes(a) || pageTokens.includes(a) || (pageBrand && pageBrand === a))) {
          return true;
        }
      }
    }
  }

  return false;
}

async function handleGetAutofillSuggestions({ fieldType, domain }) {
  // CRITICAL SECURITY CATCH: Check authorization from mobile application
  if (!memoryVault.isAuthorized || !memoryVault.isUnlocked) {
    return {
      authorized: false,
      message: 'Authorize on TetherPass mobile app to enable autofill',
      cards: [],
      bankAccounts: [],
      passwords: []
    };
  }

  // Check expiration
  if (memoryVault.authExpiresAt && Date.now() > memoryVault.authExpiresAt) {
    await lockVault('Session expired');
    return {
      authorized: false,
      message: 'Mobile session expired. Please re-authorize on phone.',
      cards: [],
      bankAccounts: [],
      passwords: []
    };
  }

  const isCredentialField = ['USER_ID', 'PASSWORD', 'TOTP'].includes(fieldType);
  const isCardField = ['CARD_NUMBER', 'EXPIRY', 'CVV', 'CARD_HOLDER'].includes(fieldType);
  const isBankField = ['ACCOUNT_NUMBER', 'IFSC'].includes(fieldType);

  // Pre-check: Does this current domain specifically match any bank in the vault?
  const domainMatchingBank = (domain && fieldType !== 'ALL') ? memoryVault.items.find(item => {
    const type = (item.type || '').toLowerCase();
    if (type === 'card' || type === 'password') return false;
    const bWeb = item.website || item.url || '';
    const bName = [item.bank_name, item.bankName, item.nickname].filter(Boolean).join(' ');
    return doesDomainMatch(bWeb, domain, bName);
  }) : null;

  // Group items using universal normalizer for Flutter VaultItem maps
  const cards = [];
  const bankAccounts = [];
  const passwords = [];

  for (const item of memoryVault.items) {
    const type = (item.type || '').toLowerCase();
    const isPassword = type === 'password';
    const rawCardNumber = String(item.card_number || item.cardNumber || item.number || item.cardNo || item.card_no || '').replace(/\s+/g, '');
    const isCard = !isPassword && (type === 'card' || (!type.includes('bank') && (rawCardNumber.length >= 12 || (item.card_network || item.cardNetwork))));

    if (isPassword) {
      if (isCardField || isBankField) continue; // Don't include passwords when filling card or bank number

      const website = item.website || '';
      const nickname = item.nickname || item.bank_name || 'Website Password';

      // Fast synchronous domain matching BEFORE generating TOTP codes:
      // Only compute crypto for items actually matching the current website!
      if (domain && fieldType !== 'ALL') {
        if (!doesDomainMatch(website, domain, nickname)) {
          continue;
        }
      }

      const totpKey = item.totp_secret || item.totpSecret || '';
      let totpCode = '';
      let totpSeconds = 0;
      if (totpKey) {
        try {
          totpCode = await generateTotpCode(totpKey);
          totpSeconds = getTotpRemainingSeconds();
        } catch (_) {}
      }

      const pwdItem = {
        id: item.id || String(Math.random()),
        nickname: nickname,
        website: website,
        username: item.user_id || item.userId || item.username || '',
        password: item.login_password || item.loginPassword || item.password || '',
        totpSecret: totpKey,
        totpCode: totpCode,
        totpSeconds: totpSeconds,
        notes: item.notes || ''
      };

      passwords.push(pwdItem);
    } else if (isCard) {
      if (isCredentialField || isBankField) continue; // Don't include cards for login or bank fields
      cards.push({
        id: item.id || String(Math.random()),
        nickname: item.nickname || item.name || item.card_holder || item.cardHolder || 'Card',
        bankName: item.bank_name || item.bankName || 'Card',
        cardNumber: rawCardNumber,
        cardHolder: item.card_holder || item.cardHolder || '',
        expiry: item.expiry || item.card_expiry || item.cardExpiry || '',
        cvv: item.cvv || item.card_cvv || item.cardCvv || '',
        cardNetwork: item.card_network || item.cardNetwork || 'Visa',
        isCredit: (item.card_type || item.cardType || '').toLowerCase().includes('credit') || !!item.isCredit,
        isDebit: (item.card_type || item.cardType || '').toLowerCase().includes('debit') || !!item.isDebit
      });
    } else {
      // NetBanking & Bank Accounts
      if (isCardField) continue; // Don't include bank accounts for card payment fields

      const bankWeb = item.website || item.url || '';
      const bankName = [item.bank_name, item.bankName, item.nickname].filter(Boolean).join(' ') || 'Bank';
      const matchesBank = domain ? doesDomainMatch(bankWeb, domain, bankName) : true;

      // STRICT DOMAIN RELEVANCE:
      // If user is on a specific webpage and requesting autofill suggestions for an input field:
      // 1. If this domain specifically belongs to a bank (e.g. HDFC, Federal, SBI),
      //    ONLY return the bank matching this domain! Never show Federal/SBI on HDFC!
      // 2. If this is a login/credential field on a non-bank site (e.g. Amazon, GitHub),
      //    NEVER return bank accounts!
      if (domain && fieldType !== 'ALL') {
        if (domainMatchingBank) {
          if (!matchesBank) {
            continue; // Filter out all non-matching banks on bank portal!
          }
        } else if (isCredentialField) {
          if (!matchesBank) {
            continue; // Do NOT suggest bank accounts on Amazon, GitHub, Netflix!
          }
        }
      }

      let rawAccounts = [];
      if (item.accounts) {
        try {
          rawAccounts = typeof item.accounts === 'string' ? JSON.parse(item.accounts) : item.accounts;
        } catch (_) {}
      }

      const normalizedAccounts = [];
      if (Array.isArray(rawAccounts) && rawAccounts.length > 0) {
        for (const a of rawAccounts) {
          const accNum = String(a.account_number || a.accountNumber || a.accountNo || a.acc_num || a.acc_no || a.accNo || '').trim();
          const ifsc = String(a.ifsc_code || a.ifscCode || a.ifsc || '').trim().toUpperCase();
          if (accNum || ifsc) {
            normalizedAccounts.push({
              accountNumber: accNum,
              ifscCode: ifsc,
              label: a.label || ''
            });
          }
        }
      }

      const primaryAcc = String(item.account_number || item.accountNumber || item.accountNo || item.acc_num || item.acc_no || item.accNo || '').trim();
      const primaryIfsc = String(item.ifsc_code || item.ifscCode || item.ifsc || '').trim().toUpperCase();
      if ((primaryAcc || primaryIfsc) && !normalizedAccounts.some(a => a.accountNumber === primaryAcc && a.accountNumber !== '')) {
        normalizedAccounts.unshift({
          accountNumber: primaryAcc,
          ifscCode: primaryIfsc,
          label: 'Primary'
        });
      }

      const bankItem = {
        id: item.id || String(Math.random()),
        bankName: bankName,
        nickname: item.nickname || '',
        website: bankWeb,
        accounts: normalizedAccounts,
        userId: item.user_id || item.userId || item.username || '',
        cifNumber: item.cif_number || item.cifNumber || item.cif || '',
        loginPassword: item.login_password || item.loginPassword || item.password || '',
        profilePassword: item.profile_password || item.profilePassword || '',
        mpin: item.mpin || '',
        notes: item.notes || ''
      };

      bankAccounts.push(bankItem);

      // If user is on a login field and this bank matches the domain, also push a password representation
      // so content.js and popup.js can easily render and autofill the login details
      if (isCredentialField && (bankItem.userId || bankItem.loginPassword)) {
        passwords.push({
          id: item.id || String(Math.random()),
          nickname: bankName + ' NetBanking',
          website: bankWeb || domain,
          username: bankItem.userId,
          password: bankItem.loginPassword,
          totpSecret: item.totp_secret || item.totpSecret || '',
          totpCode: '',
          totpSeconds: 0,
          notes: item.notes || '',
          isBankLogin: true
        });
      }
    }
  }

  return {
    authorized: true,
    cards,
    bankAccounts,
    passwords
  };
}

async function handleSaveNewPassword({ website, username, password, nickname, totpSecret }) {
  if (!memoryVault.isUnlocked || !memoryVault.masterPassword) {
    return { success: false, error: 'VAULT_LOCKED', message: 'TetherPass extension is locked.' };
  }

  const cleanDomain = extractDomain(website) || 'login';
  const now = new Date().toISOString();

  // Find if already present
  let existingIndex = memoryVault.items.findIndex(it => {
    const isPwd = (it.type || '').toLowerCase() === 'password';
    if (!isPwd) return false;
    const sameDomain = doesDomainMatch(it.website, cleanDomain);
    const sameUser = (it.user_id || it.userId || it.username || '').toLowerCase() === (username || '').toLowerCase();
    return sameDomain && sameUser;
  });

  const newItem = {
    id: existingIndex >= 0 ? memoryVault.items[existingIndex].id : 'item_' + Date.now(),
    type: 'password',
    bank_name: nickname || cleanDomain,
    nickname: nickname || cleanDomain,
    website: (website || '').startsWith('http') ? website : `https://${website || cleanDomain}`,
    user_id: username,
    login_password: password,
    totp_secret: totpSecret || (existingIndex >= 0 ? (memoryVault.items[existingIndex].totp_secret || '') : ''),
    notes: existingIndex >= 0 ? (memoryVault.items[existingIndex].notes || '') : 'Saved via TetherPass Chrome Extension',
    created_at: existingIndex >= 0 ? memoryVault.items[existingIndex].created_at : now,
    updated_at: now
  };

  if (existingIndex >= 0) {
    memoryVault.items[existingIndex] = newItem;
  } else {
    memoryVault.items.push(newItem);
  }

  // Encrypt and persist to Google Drive if connected
  try {
    const encryptedPayload = await encryptTetherPassBackup(memoryVault.items, memoryVault.masterPassword);
    await driveClient.uploadOrUpdateFile(DRIVE_BACKUP_FILENAME, encryptedPayload);
  } catch (err) {
    console.warn('[TetherPass] Could not upload updated backup to Drive:', err);
  }

  // Persist updated vault items into session storage
  await persistSession();

  notifyAllTabsStatusChange();
  return { success: true, updated: existingIndex >= 0, title: newItem.nickname };
}

// Periodic check every 4 seconds so revocations from mobile take effect promptly
setInterval(verifyMobileAuth, 4000);
